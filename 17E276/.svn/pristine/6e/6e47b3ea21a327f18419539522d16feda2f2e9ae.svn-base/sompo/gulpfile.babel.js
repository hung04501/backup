'use strict';

// import
import gulp from 'gulp';
import source from 'vinyl-source-stream';
import stylus from 'gulp-stylus';
import pleeease from 'gulp-pleeease';
import aigis from 'gulp-aigis';
import watchify from 'watchify';
import browserify from 'browserify';
import babelify from 'babelify';
import ejs from 'gulp-ejs';
import jsbeautifier from 'gulp-jsbeautifier';
import browserSync from 'browser-sync';
import readConfig from 'read-config';
import watch from 'gulp-watch';
// import RevLogger from 'rev-logger';
import cache from 'gulp-memory-cache';
import del from 'del';
import removeEmptyLines from 'gulp-remove-empty-lines';

// const
const SRC = './src';
const CONFIG = './config';
const HTDOCS = './public';
const BASE_PATH = '';
const DEST = `${HTDOCS}${BASE_PATH}`;
// let browserSync = {};
// browserSync.stream = () => {};

// const revLogger = new RevLogger({
//   'style.css': `${DEST}/css/style.css`,
//   'script.js': `${DEST}/js/script.js`
// });

// Clean build folder
gulp.task('clean', () => del(`${HTDOCS}/**/*`));

// css
gulp.task('stylus', () => {
  const config = readConfig(`${CONFIG}/pleeease.json`);
  return gulp.src(`${SRC}/stylus/style.styl`)
    .pipe(stylus())
    .pipe(pleeease(config))
    .pipe(gulp.dest(`${DEST}/assets/css`))
    .pipe(browserSync.stream());
});

// Styleguide
gulp.task('styleguide', () =>
  gulp.src(`${CONFIG}/aigis_config.yml`)
    .pipe(aigis())
)

gulp.task('styleguide-theme', () =>
  gulp.src(`${SRC}/styleguide/**/*.styl`)
    .pipe(stylus())
    .pipe(gulp.dest(`${DEST}/styleguide/`))
)

gulp.task('css', gulp.series('stylus'));

// js
gulp.task('watchify', () => {
  return watchify(browserify(`${SRC}/js/script.js`))
    .transform(babelify)
    .bundle()
    .pipe(source('script.js'))
    .pipe(gulp.dest(`${DEST}/js`));
});

gulp.task('js', gulp.parallel('watchify'));

//ejsTask
const ejsTask = (lang) => {
  //出力先フォルダを設定
  let destDir = DEST + '/' + lang;
  if(lang === "default") {
    destDir = DEST;
  }

  //   if(lang === 'ja') destDir =  DEST+'/';

  // //JSON指定
  // let locals = {
  //   'global': readConfig(`${SRC}/json/meta/meta_${lang}.json`),
  //   'breadcrumb': readConfig(`${SRC}/json/breadcrumb/breadcrumb_${lang}.json`),
  //   'top': readConfig(`${SRC}/json/top/top_${lang}.json`),
  //   'header': readConfig(`${SRC}/json/header/header_${lang}.json`)
  // };
  // locals.versions = revLogger.versions();
  // locals.basePath = BASE_PATH;
  return gulp.src(`${SRC}/pages/**/[!_]*.ejs`, {since: cache.lastMtime('ejs')})
    .pipe(cache('ejs'))
    .pipe(ejs({
    }, {
      root: process.cwd() + "/src",
    }, {
      ext: '.html'
    }))
    .pipe(jsbeautifier({
      debug: false,
      indent_char: ' ',
      indent_size: 2,
      html: {
        unformatted: ['sub', 'sup', 'b', 'i', 'u', 'br', 'span'],
      }
    }))
    .pipe(removeEmptyLines())
    .pipe(gulp.dest(`${destDir}`));
}

//日本語タスク
gulp.task('html', () => {
  console.log("ejs:default");
  return ejsTask('default');
});


//日・英両タスクを1つのタスクにまとめる
//gulp.task('html', gulp.series('ejs:default'));

// serve
gulp.task('browser-sync', () => {
  browserSync({
    server: {
      baseDir: HTDOCS
    },
    startPath: `${BASE_PATH}/`,
    ghostMode: false
  });

  watch([`${SRC}/**/*.styl`], gulp.series('stylus', 'styleguide'));
  // watch([`${SRC}/js/**/*.js`], gulp.series('watchify', browserSync.reload));
  watch([SRC + "/**/*.{js,ico,json,xml,woff,woff2,ttf,eot,mp4,webm,jpeg,jpg,gif,png,map,mp3,svg}"], gulp.series('copy', 'styleguide', browserSync.reload));
  watch([
    `${SRC}/**/*.ejs`,
    `${SRC}/json/**/*.json`,
  ], gulp.series('html', 'styleguide', browserSync.reload)).on('change', cache.update('js'));

  // revLogger.watch((changed) => {
  //   gulp.series('html', browserSync.reload)();
  // });
});

gulp.task('copy', () => {
  return gulp.src(SRC + "/**/*.{js,ico,json,xml,woff,woff2,ttf,eot,mp4,webm,jpeg,jpg,gif,png,map,mp3,svg}", {since: cache.lastMtime('copy')}) //FIXME: pleeease.jsonの設定ファイルがコピーされるのを防ぐ
    .pipe(cache('copy'))
    .pipe(gulp.dest(`${DEST}`))
    .pipe(browserSync.stream());

});

gulp.task('serve', gulp.series('browser-sync'));


// default
gulp.task('build', gulp.parallel('css', 'html', 'styleguide', 'copy'));
gulp.task('default', gulp.series('build', 'serve'));
