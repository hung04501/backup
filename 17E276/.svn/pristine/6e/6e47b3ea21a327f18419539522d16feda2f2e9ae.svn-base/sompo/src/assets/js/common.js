/* globals Chart $ bowser Swiper Mustache Class SRCPortal Parsley autosize */


var SRCPortal = SRCPortal ? SRCPortal : {};
SRCPortal.state = {
  browser: {
    isAndroidRegacy: false,
    isPCWidth: true,
  }
};

SRCPortal.Init = Class.extend({
  __construct: function() {
    SRCPortal.$window = $(window);
    SRCPortal.$document = $(document);
    SRCPortal.$html = $("html");
  }
});

SRCPortal.Base = Class.extend({
  $window: null,
  $document: null,
  $html: null,
  THROTTLE_DURATION: 200,
  __construct: function(){
    this.$window = SRCPortal.$window;
    this.$document = SRCPortal.$document;
    this.$html = SRCPortal.$html;
  },
});

SRCPortal.Common = SRCPortal.Base.extend({
  __construct: function() {
    this.__super.__construct.call(this);
    this.polyFillcreateObjectURL();
    this.checkBrowser();
    this.preventZoomOnSafari();
    this.checkWindowWidth();
  },
  polyFillcreateObjectURL: function() {
    var URL = window.URL || window.webkitURL;
    window.createObjectURL = URL ? URL.createObjectURL : null;
  },
  checkBrowser: function() {
    var me = this;
    var ua = window.navigator.userAgent;

    //androidレガシーブラウザか
    if (/Android/.test(ua) && /Linux; U;/.test(ua) && !/Chrome/.test(ua)) {
      me.$html.addClass('is-androidRegacy');
      SRCPortal.state.browser.androidRegacy = true;
    } else {
      me.$html.addClass('is-notAndroidRegacy');
    }

    if (bowser.ios) {
      me.$html.addClass('is-iOS');
    } else {
      me.$html.addClass('is-notiOS');
    }

    if (bowser.msie) {
      me.$html.addClass('is-ie');
    } else {
      me.$html.addClass('is-notIe');
    }

    if (bowser.msedge) {
      me.$html.addClass('is-edge');
    } else {
      me.$html.addClass('is-notEdge');
    }

    if (bowser.firefox) {
      me.$html.addClass('is-firefox');
    } else {
      me.$html.addClass('is-notFirefox');
    }

    //hoverできるか
    if (bowser.mobile || bowser.tablet) {
      me.$html.addClass('is-noHoverable');
    }
    this.$document.one('touchstart', function() {
      me.$html.addClass('is-noHhoverable');
    });


  },
  preventZoomOnSafari: function() {
    //refer: http://qiita.com/EudyptesCapital/items/d74e5758a36478fbc039
    var TARGET_IOS_VER_FLOOR = 10;
    var ZOOM_THRESHOLD_DURATION = 500;

    if (bowser.ios && bowser.version >= TARGET_IOS_VER_FLOOR) {
      document.addEventListener('touchstart', function(e) {
        if (e.touches.length > 1) {
          e.preventDefault();
        }
      }, true);

      var lastTouch = 0;
      document.addEventListener('touchend', function(e) {
        var now = window.performance.now();
        if (now - lastTouch <= ZOOM_THRESHOLD_DURATION) {
          e.preventDefault();
        }
        lastTouch = now;
      }, true);
    }
  },
  checkWindowWidth: function() {
    var SP_MAX_WID = 767;
    var check = function() {
      if (window.innerWidth > SP_MAX_WID) {
        SRCPortal.state.browser.isPCWidth = true;
      } else {
        SRCPortal.state.browser.isPCWidth = false;
      }
    };
    this.$window.on('resize orientationchange', function() {
      check();
    });
    check();
  }
});

SRCPortal.Chart = SRCPortal.Base.extend({
  __construct: function() {
    this.__super.__construct.call(this);
    this.doGlobalSetting();
    this.drawDoughnutChart();
    this.drawLineChart();
  },
  doGlobalSetting: function() {
    var chartGlobalSettings = {
      responsive: true,
      animation: {
        duration: 0
      },
      legend: {
        display: false,
      }
    };
    $.extend(true, Chart.defaults.global, chartGlobalSettings);
  },
  drawDoughnutChart: function() {
    var me = this;
    var OPTIONS = {
      cutoutPercentage: 100 - 21.8,
      tooltips: {enabled: false},
      hover: {mode: null},
      responsive: true,
      maintainAspectRatio: false,
      elements: {
        line: {
          borderWidth: 2,
          fill: false,
        },
        point: {
          radius: 0
        },
      },
      animation: {}
    };

    if (SRCPortal.state.browser.isPCWidth) {
      OPTIONS.cutoutPercentage = 100 - 19.6;
    }

    $(".js-chart--doughnut").each(function() {
      var $this = $(this);
      var datasets = $this.data("doughnut-chart-dataset");
      var isAnimate = !!$this.data("doughnut-chart-animate");
      var _options = $.extend(true, {}, OPTIONS);
      var ctx = $this.get(0).getContext("2d");
      if (isAnimate) {
        _options.animation.duration = 1000;
      }
      datasets.forEach(function(val, idx) {
        if (val.data.length > 1 && val.data[1] === 0 && SRCPortal.state.browser.androidRegacy) { //androidですべてぬりつぶされてしまう事象の対策
          val.data[1] = 1;
          val.backgroundColor[1] = val.backgroundColor[0];
        }
        val.backgroundColor = val.backgroundColor.map(function(colorString) {
          return me._generateColorByColorString(ctx, colorString);
        });
        val.borderWidth = val.data.map(function() {
          return 0;
        });
      });
      if (isAnimate) {
        setTimeout(function() {
          new Chart(ctx, {
            type: 'pie',
            data: {
              datasets: datasets
            },
            options: _options
          });
        }, 1000);
      } else {
        var oChart = new Chart(ctx, {
          type: 'pie',
          data: {
            datasets: datasets
          },
          options: _options
        });
        me.$window.on("tabchange", function() {
          oChart.destroy();
          oChart = new Chart(ctx, {
            type: 'pie',
            data: {
              datasets: datasets
            },
            options: _options
          });
        });
      }
    });
  },
  drawLineChart: function() {
    var me = this;
    var OPTIONS = {
      responsive: true,
      hoverMode: 'index',
      stacked: false,
      maintainAspectRatio: false,
      tooltips: {
        enabled: false,
        mode: 'index',
        filter: function(val, datasets) {
          return !!datasets.datasets[val.datasetIndex].isBody;
        },
        intersect: false,
      },
      hover: {
        mode: null,
      },
      title: {
        display: false,
      },
      legend: {
        display: false,
      },
      layout: {
        padding: {
          // Any unspecified dimensions are assumed to be 0
          left: 10,
          top: 24
        }
      },
      scales: {
        xAxes: [
          {
            id: "x-axis-1",
            type: 'SRCPortalXAxis',
            gridLines: {
              display: true,
              drawTicks: false,
              zeroLineColor: "transparent",
              color: "rgba(224,232,232,0.3)",
            },
            ticks: {
              padding: 14,
              fontColor: "#405060",
              fontFamily: 'Noto Sans Japanese',
              fontSize: 11,
              autoSkipPadding: 20,
              maxRotation: 0,
              minor: {
                padding: 14
              }
              // labelOffset: 30,
            },
          }
        ],
        yAxes: [{
          type: "SRCPortalYAxis",
          display: true,
          position: "left",
          id: "y-axis-1",
          gridLines: {
            display: false,
            color: "rgba(224,232,232, 0.3)",
          },
          scaleLabel: {
            labelString: 'Value',
            fontColor: "#405060",
            fontFamily: "Yantramanav",
            display: true
          },
          ticks: {
            fontColor: "#405060",
            padding: 10,
            fontFamily: 'Yantramanav',
            userCallback: function(val, idx, vals) { return Math.round(val); },
            suggestedMin: 0,
            maxTicksLimit: 8,
            suggestedMax: 10,
          },
          afterSetDimensions: function(axes) {
            axes.maxWidth = 54;
          }
        }, {
          type: "SRCPortalYAxis",
          display: true,
          position: "right",
          id: "y-axis-2",
          // grid line settings
          gridLines: {
            display: false,
            drawBorder: false
          },
          scaleLabel: {
            labelString: 'Value',
            fontColor: "rgba(255,255,255,0.0)",
            fontFamily: "Yantramanav",
            display: true
          },
          ticks: {
            fontColor: "rgba(255,255,255,0.0)",
            padding: 0,
            fontFamily: 'Yantramanav',
            maxTicksLimit: 8,
            userCallback: function(val, idx, vals) { return Math.round(val); },
            suggestedMin: 0,
            suggestedMax: 10
          },
          afterSetDimensions: function(axes) {
            axes.maxWidth = 40;
          }
        }],
      }
    };

    $(".js-chart--line").each(function() {
      var $this = $(this);
      var _options = $.extend(true, {}, OPTIONS);
      var mergedDataset = [];
      var isToShowLabel = $this.data("line-chart-show-tooltip") === "always";
      var isToShowTooltip = $this.data("line-chart-show-tooltip") === "hover";
      _options.tooltips.custom = isToShowTooltip ? Chart.defaults.global.hover.custom : null;
      _options.hover.mode = isToShowTooltip ? "index" : "null";
      _options.showLatestTooltip = isToShowTooltip;
      var datasets = $this.data("line-chart-dataset");
      var labels = $this.data("line-chart-labels");
      var ctx = $this.get(0).getContext("2d");

      //共通設定

      var borderColor = [];
      borderColor[0] = "#68c8d8";
      borderColor[1] = "#6890d8";

      var pointProps = [
        {
          pointBorderColor: "#68c8d8",
          pointBackgroundColor: "#ffffff",
          pointRadius: 3,
          pointHoverBorderColor: "#68c8d8",
          pointHoverBackgroundColor: "#ffffff",
          pointHoverRadius: 3,
          pointBorderWidth: 2,
          pointHoverBorderWidth: 2
        },
        {
          pointBorderColor: "#6890d8",
          pointBackgroundColor: "#ffffff",
          pointRadius: 3,
          pointHoverBorderColor: "#6890d8",
          pointHoverBackgroundColor: "#ffffff",
          pointHoverRadius: 3,
          pointBorderWidth: 2,
          pointHoverBorderWidth: 2
        }
      ];

      //datasets加工
      datasets.forEach(function(val, idx) {
        //datassetの共通設定
        val.borderWidth = 2;
        val.borderColor = borderColor[idx];
        val.lineTension = 0;
        val.isShowLabel = isToShowLabel;
        val.fill = false;
        val.pointRadius = 0;
        val.isBody = true;
        _options.scales.yAxes.forEach(function(yAxesVal) {
          if (yAxesVal.id === val.yAxisID) {
            yAxesVal.scaleLabel.fontColor = "#405060";
            yAxesVal.ticks.fontColor = "#405060";
            yAxesVal.scaleLabel.labelString = val.scaleLabel;
            if (val.yAxisType === "time") {
              yAxesVal.ticks.userCallback = function(label, index, labels) {
                var _label = parseInt(label, 10);
                var _h = Math.floor(_label / 60);
                var _m = (_label / 60 - _h) * 60;
                var _unit = 30;  // 単位(_unitの倍数)
                _m = Math.floor(_m / _unit) * _unit; //XXX stepが怪しくなってしまうので調整が必要かもしれない。min, maxふくめ。

                return String(_h) + ":" + ("00" + String(_m)).slice(-2);
              };
            }
          }
        });

        //グラフの最小値、最大値の設定
        var _average = val.data.reduce(function(prev, current) { return prev + current; }) / val.data.length;
        var _min = Math.min.apply({}, val.data);
        var _max = Math.max.apply({}, val.data);
        var _unit = 5;  // 単位(_unitの倍数)
        _options.scales.yAxes[idx].ticks.suggestedMin = Math.floor((_min - (_average - _min)) / _unit) * _unit;
        _options.scales.yAxes[idx].ticks.suggestedMax = Math.ceil((_max + (_max - _average)) / _unit) * _unit;
        if (_options.scales.yAxes[idx].ticks.suggestedMin < 0) {
          _options.scales.yAxes[idx].ticks.suggestedMin = 0;
        }

      });

      var datasetsPoint = [];
      if (!datasets[0].showOnlyCurrentPoint) {
        datasetsPoint = $.extend(true, [], datasets); //deep copy

        // pointは別グラフとして描画する。
        datasetsPoint.forEach(function(val, idx) {
          val.showLine = false;
          val.isShowLabel = false;
          val.isBody = false;
          val.pointHitRadius = 10;
          val.pointHoverRadius = 10;
          $.extend(val, pointProps[idx]);
        });
      }

      //目標の線があるとき
      var datasetTargetLine = [];
      var targetLineDataset = $this.data("line-chart-target-line-dataset");
      if (targetLineDataset) {
        targetLineDataset.forEach(function(val, idx) {
          val.pointRadius = 0;
          val.borderDash = [2, 2];
          val.borderWidth = 1;
          val.borderColor = "#687070";
          val.fill = false;
          val.isShowLabel = false;
        });
        if (_options.scales.yAxes[0].ticks.suggestedMin >= targetLineDataset[0].data[0]) {
          var _min = Math.min.apply({}, targetLineDataset[0].data);
          var _max = Math.max.apply({}, targetLineDataset[0].data);
          var _unit = 5;  // 単位(_unitの倍数)
          _options.scales.yAxes[0].ticks.suggestedMin = Math.floor((_min + _min - _options.scales.yAxes[0].ticks.suggestedMin) / _unit) * _unit;
          if (_options.scales.yAxes[0].ticks.suggestedMin < 0) {
            _options.scales.yAxes[0].ticks.suggestedMin = 0;
          }
        }
        datasetTargetLine = targetLineDataset;
      }

      //目標の範囲があるとき
      var datasetTargetArea = [];
      var targetAreaDataset = $(this).data("line-chart-target-area-dataset");
      if (targetAreaDataset) {
        targetAreaDataset.forEach(function(val, idx) {
          val.fill = false;
          val.borderWidth = 0.1;
          val.borderColor = "transparent";
          if (idx % 2 === 1) {
            val.fill = "-1";
            var gradients = ctx.createLinearGradient(0, 80, 0, 250);
            if (idx % 3 !== 0) {
              gradients.addColorStop(0, 'rgba(152,232,224,0.3)');
              gradients.addColorStop(1, 'rgba(104,200,216,0.3)');
            } else {
              gradients.addColorStop(0, 'rgba(167,204,235,0.3)');
              gradients.addColorStop(1, 'rgba(137,170,211,0.3)');
            }
            val.backgroundColor = gradients;
          }
          val.isShowLabel = false;
          val.pointRadius = 0;
        });
        if (_options.scales.yAxes[0].ticks.suggestedMin >= targetAreaDataset[0].data[0]) {
          var _min = Math.min.apply({}, targetAreaDataset[0].data);
          var _max = Math.max.apply({}, targetAreaDataset[0].data);
          var _unit = 5;  // 単位(_unitの倍数)
          _options.scales.yAxes[0].ticks.suggestedMin = Math.floor((_min + _min - _options.scales.yAxes[0].ticks.suggestedMin) / _unit) * _unit;
          if (_options.scales.yAxes[0].ticks.suggestedMin < 0) {
            _options.scales.yAxes[0].ticks.suggestedMin = 0;
          }
        }
        datasetTargetArea = targetAreaDataset;
      }

      Array.prototype.push.apply(mergedDataset, datasetTargetLine);
      Array.prototype.push.apply(mergedDataset, datasetsPoint);
      Array.prototype.push.apply(mergedDataset, datasetTargetArea);
      Array.prototype.push.apply(mergedDataset, datasets);

      var oChart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: mergedDataset
        },
        options: _options
      });
      me.$window.on("tabchange", function() {
        oChart.destroy();
        $this.siblings(".a-chart-line__tooltip").remove();
        oChart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: labels,
            datasets: mergedDataset
          },
          options: _options
        });
      });
    });
  },
  _generateColorByColorString: function(ctx, colorString) {
    var color = null;
    if (colorString.indexOf("gradation-") > -1) {
      color = ctx.createLinearGradient(0, 0, 216, 0);
    }
    switch (colorString) {
      case "gradation--red":
        color.addColorStop(0, 'rgb(248,160,160)');
        color.addColorStop(1, 'rgb(248,136,136)');
        break;
      case "gradation--yellow":
        color.addColorStop(1, 'rgb(248,168,80)');
        color.addColorStop(0, 'rgb(248,204,124)');
        break;
      case "gradation--green":
        color.addColorStop(1, 'rgb(112,208,192)');
        color.addColorStop(0, 'rgb(168,240,216)');
        break;
      case "gradation--blue":
        color.addColorStop(1, 'rgb(104,200,216)');
        color.addColorStop(0, 'rgb(152,232,224)');
        break;
      case "legend--1":
        color = "#86e2d5";
        break;
      case "legend--2":
        color = "#73c4e4";
        break;
      case "legend--3":
        color = "#49a5d4";
        break;
      case "legend--4":
        color = "#5e74b1";
        break;
      case "legend--5":
        color = "#b264a7";
        break;
      case "legend--6":
        color = "#d36666";
        break;
      case "legend--7":
        color = "#f5a95b";
        break;
      case "legend--8":
        color = "#f1df80";
        break;
      case "legend--9":
        color = "#9ede95";
        break;
      case "legend--10":
        color = "#64d39a";
        break;
      default:
        color = colorString;
    }
    return color;
  }
});

SRCPortal.MealRecord = SRCPortal.Base.extend({
  API_URL: SRCPortal.CONST.API_EATSMART,
  __construct: function() {
    this.__super.__construct.call(this);
    this.doSearch();
    this.registerMeal();
    this.searchResultHeight();
    this.mealHistoryMaxHeight();
  },
  doSearch: function() {
    var me = this;
    var API_URL = this.API_URL;
    var $searchBoxWrapper = $(".js-search-box");
    var $searchResults = $searchBoxWrapper.find(".m-link-group--search-results");
    var $searchBox = $searchBoxWrapper.find("input[type='search']");
    var $loadAnime = $searchResults.find(".a-load-anime");
    var $searchBtn = $searchBoxWrapper.find(".js-search-box__submit");
    var $serchForm = $(".js-search-form");
    $serchForm.on("submit", function(e) {
      e.preventDefault();
      var $searchWord = $searchBox.val();
      if (!$searchWord.match(/^[ 　\r\n\t]*$/)) {
        //スライド出す
        var showResultsBox = function() {
          var d = new $.Deferred();
          $searchResults.velocity("slideDown", {
            duration: 300, easing: "ease", complete: function() {
              d.resolve();
            }
          });
          return d.promise();
        };

        //apiコール
        var apiCall = function() {
          return $.ajax({
            url: API_URL,
            method: 'GET'
          });
        };

        //アニメーションフェードアウト
        var loadAnime = function() {
          var d = new $.Deferred();
          $loadAnime.velocity("fadeOut", {
            display: "none", duration: 100, easing: "ease", complete: function() {
              d.resolve();
            }
          });
          return d.promise();
        };

        // 検索結果をappend
        var appendSearchResult = function() {
          var d = new $.Deferred();
          var DUMMY_DOM = '<li class="m-link-group--search-results__result"><a class="js-meal-search-entry">シーチキンおにぎり（xxxx kcal）</a></li>\
                            <li class="m-link-group--search-results__result"><a class="js-meal-search-entry">昆布おにぎり（xxxx kcal）</a></li>\
                            <li class="m-link-group--search-results__result"><a class="js-meal-search-entry">激辛わさびマヨネーズソーセージおにぎり（xxxx kcal）</a></li>\
                            <li class="m-link-group--search-results__result"><a class="js-meal-search-entry">〇〇おにぎり（xxxx kcal）</a></li>\
                            <li class="m-link-group--search-results__result"><a class="js-meal-search-entry">〇〇おにぎり（xxxx kcal）</a></li>\
                            <li class="m-link-group--search-results__result"><a class="js-meal-search-entry">〇〇おにぎり（xxxx kcal）</a></li>\
                            <li class="m-link-group--search-results__result"><a class="js-meal-search-entry">〇〇おにぎり（xxxx kcal）</a></li>\
                            <li class="m-link-group--search-results__result"><a class="js-meal-search-entry">〇〇おにぎり（xxxx kcal）</a></li>\
                            <li class="m-link-group--search-results__result"><a class="js-meal-search-entry">〇〇おにぎり（xxxx kcal）</a></li>';
          $searchResults.append(DUMMY_DOM);
          d.resolve();
          return d.promise();
        };

        // 検索結果出す
        var showResults = function() {
          var d = new $.Deferred();
          var $searchResult = $searchResults.find("li.m-link-group--search-results__result");
          $searchResults.css("min-height", "0");
          $searchResult.velocity("fadeIn", {
            duration: 100, easing: "ease", complete: function() {
              d.resolve();
            }
          });
          me.$document.on("click.mealResult", function(event) {
            if (!$(event.target).closest($searchBtn).length) {
              me.$document.off(".mealResult");
              $searchResults.velocity("slideUp", {
                display: "none", duration: 300, easing: "ease", complete: function() {
                  $searchResult.remove();
                  $searchResults.css("min-height", "");
                  $loadAnime.css("display", "block").css("opacity", "");
                }
              });
            }
          });
          $searchBox.val("");
          $searchBtn.attr('disabled', 'disabled');
          return d.promise();
        };

        // 検索結果の窓の高さを設定
        var resultsHeight = function() {
          var d = new $.Deferred();
          var $searchResults = $(".m-link-group--search-results");
          $searchResults.css("height", "");
          if (!SRCPortal.state.browser.isPCWidth) {
            var $windowHeight = me.$window.height();
            var $searchResultsHeight = $windowHeight - 108;
            $searchResults.css("height", $searchResultsHeight);
          }
          d.resolve();
          return d.promise();
        };

        var def = $.Deferred(function(d) {
          d.then(showResultsBox).then(loadAnime).then(apiCall).then(appendSearchResult).then(showResults).then(resultsHeight);
        });
        def.resolve();
      }
    });
  },
  registerMeal: function() {
    var $entryMeal = $(".js-meal-search-entry");
    var $dashboardEmpty = $(".o-dashboard-empty");
    var $mealTable = $(".m-table--entry-meal");
    var template = $("#js-entry-meal-data").html();
    var $mealHistoryArea = $("#dropdown-history");
    var $mealHistoryForm = $mealHistoryArea.find(".o-form");
    var $mealInputArea = $("#dropdown-entry-meal");
    var $mealInputForm = $mealInputArea.find(".o-form");
    var $mealNameInputArea = $(".js-meal-input-name");
    var $mealKcalInputArea = $(".js-meal-input-kcal");
    var $menuBtnHistory = $(".o-header__menu__btn--history");
    var $menuBtnEntryMeal = $(".o-header__menu__btn--entry-meal");
    var $fixedMenu = $(".o-fixed-menu--meal-log");
    Mustache.parse(template);

    var _mealCount = 0;

    var updateMealCount = function(add) {
      var CLASS_VISIBLE = "is-visible";
      _mealCount += add;
      if (_mealCount < 1) {
        $fixedMenu.removeClass(CLASS_VISIBLE);
      } else {
        $fixedMenu.addClass(CLASS_VISIBLE);
      }
    };

    this.$document.on("click", ".js-meal-search-entry", function(e) {
      e.preventDefault();
      $dashboardEmpty.addClass("u-dn");
      var $this = $(this);
      var $mealNameSearch = $this.text();
      var rendered = Mustache.render(template, {
        text: $mealNameSearch
      });
      updateMealCount(1);
      $mealTable.append(rendered);
    });

    $mealInputForm.on("submit", function(e) {
      e.preventDefault();
      $dashboardEmpty.addClass("u-dn");
      var $mealNameInput = $mealNameInputArea.val();
      var $mealKcalInput = $mealKcalInputArea.val();
      var rendered = Mustache.render(template, {
        text: $mealNameInput + "（" + $mealKcalInput + "kcal）"
      });
      updateMealCount(1);
      $mealTable.append(rendered);
      $mealNameInputArea.val("");
      $mealKcalInputArea.val("");
      $menuBtnEntryMeal.trigger("click");
    });

    $mealHistoryForm.on("submit", function(e) {
      e.preventDefault();
      $dashboardEmpty.addClass("u-dn");
      var $checkedBox = $('.js-entry-meal-check:checked');
      var $mealNameHistoryArray = [];
      $checkedBox.each(function(idx, elm) {
        var $id = $(elm).attr('id');
        var $mealNameHistory = $('label[for="' + $id + '"]').text().replace(/\s+/g, "");
        $mealNameHistoryArray.unshift($mealNameHistory);
      });
      $.each($mealNameHistoryArray, function(inx, val) {
        var rendered = Mustache.render(template, {
          text: val
        });
        updateMealCount(1);
        $mealTable.append(rendered);
      });
      $checkedBox.prop('checked', false);
      $menuBtnHistory.trigger("click");
    });

    this.$document.on("click", ".js-remove-meal", function() {
      var $this = $(this);
      var $parent = $this.parents("tr");
      $parent.remove();
      updateMealCount(-1);
      if (!$mealTable.find("tr").length) {
        $dashboardEmpty.removeClass("u-dn");
      }
    });
  },
  searchResultHeight: function() {
    var me = this;
    var timer = false;
    var $searchResults = $(".m-link-group--search-results");
    var HEIGHT_OTHER_PARTS = 108;
    me.$window.resize(
      $.throttle(me.THROTTLE_DURATION, function(){
        if (!SRCPortal.state.browser.isPCWidth) {
          var $windowHeight = me.$window.height();
          var $searchResultsHeight = $windowHeight - HEIGHT_OTHER_PARTS;
          $searchResults.css("height", $searchResultsHeight);
        }
      })
    );
  },
  mealHistoryMaxHeight: function() {
    var me = this;
    var timer = false;
    var $mealHistory = $(".js-meal-dropdown-max-height");
    var $windowHeight = me.$window.height();
    var HEIGHT_OTHER_PARTS = 221;
    var $mealHistoryMaxHeight = $windowHeight - HEIGHT_OTHER_PARTS;
    if (!$mealHistory[0]) return;

    $mealHistory.css("max-height", $mealHistoryMaxHeight);

    me.$window.resize(
      $.throttle(me.THROTTLE_DURATION, function(){
        if (!SRCPortal.state.browser.isPCWidth) {
          var $windowHeight = me.$window.height();
          var $mealHistoryMaxHeight = $windowHeight - HEIGHT_OTHER_PARTS;
          $mealHistory.css("max-height", $mealHistoryMaxHeight);
        }
      })
    );
  }
});

SRCPortal.UI = SRCPortal.Base.extend({
  __construct: function() {
    this.__super.__construct.call(this);
    this.doEllipsis();
    this.scrollTab();
    this.toggleTab();
    this.toggleSidemenu();
    this.buildSortableAddress();
    this.toggleAccordion();
    this.buildTooltip();
    this.scrollToTop();
    this.buildSwiper();
    this.toggleHeaderMenu();
    this.toggleModal();
    this.scrollTable();
    this.scrollToAnchor();
    this.togglePrintBtnByUserAgent();
    this.matchHeight();
  },
  doEllipsis: function() {
    $('.js-ellipsis').dotdotdot({
      watch: "window",
    });
  },
  scrollTab: function() {
    var $scrollTabs = $('.m-tabs--scroll');
    if (!$scrollTabs[0]) return;
    var isRunning = false;
    var oScrollTabs = null;
    if (SRCPortal.state.browser.isPCWidth) {
      oScrollTabs = $scrollTabs.scrollTabs({
        left_arrow_size: 9,
        right_arrow_size: 9
      });
      isRunning = true;
    }
    this.$window.on("resize", function() {
      if (SRCPortal.state.browser.isPCWidth && !isRunning) {
        oScrollTabs = $scrollTabs.scrollTabs({
          left_arrow_size: 9,
          right_arrow_size: 9
        });
        isRunning = true;
      } else if (!SRCPortal.state.browser.isPCWidth && isRunning) {
        oScrollTabs.destroy();
        oScrollTabs = null;
        isRunning = false;
      }
    });
  },
  toggleTab: function() {
    var me = this;
    var CLASS_TAB_GROUP = ".o-tab-group";
    var CLASS_BUTTON = ".m-tabs__body";
    var CLASS_BUTTON_ACTIVE = "m-tabs__body--active";

    var CLASS_TAB_BODY = ".o-tab-group__body__content";
    var CLASS_TAB_BODY_ACTIVE = "o-tab-group__body__content--active";
    var currentActiveTab = null;

    var $tabGroup = $(CLASS_TAB_GROUP);
    if (!$tabGroup[0]) return;

    $("[data-tab-target]").on("click", function(){
      var targetTabId = $(this).data("tab-target");
    });
    this.setTab = function(targetTabId) {
      $("[data-tab-body]")
        .removeClass(CLASS_TAB_BODY_ACTIVE)
        .filter(function(){
          return $(this).data("tab-body") === targetTabId;
        })
        .addClass(CLASS_TAB_BODY_ACTIVE);
      $("[data-tab-target]")
        .removeClass(CLASS_BUTTON_ACTIVE)
        .filter(function(){
          return $(this).data("tab-target") === targetTabId;
        })
        .addClass(CLASS_BUTTON_ACTIVE);


      // $("[data-tab-body='" + targetTabId + "']")
      // $tabGroup
      //   .find(CLASS_TAB_BODY)
      //   .removeClass(CLASS_TAB_BODY_ACTIVE)
      //   .end()
      //   .find("[data-tab-body='" + targetTabId + "']")
      //   .addClass(CLASS_TAB_BODY_ACTIVE)
      //   .end()
      //   .find(CLASS_BUTTON)
      //   .removeClass(CLASS_BUTTON_ACTIVE)
      //   .end()
      //   .find("[data-tab-target='" + targetTabId + "']")
      //   .addClass(CLASS_BUTTON_ACTIVE);

      location.hash = targetTabId;
      $.fn.matchHeight._update();
      me.$window.trigger("tabchange");
    };
    if (/tab\-/.test(location.hash)) {
      this.setTab(location.hash.replace("#", ""));
    } else {
      var tabFirst = $(CLASS_TAB_GROUP).find(CLASS_BUTTON).eq(0).data("tab-target");
      this.setTab(tabFirst);
    }

    $(CLASS_BUTTON).on('click', function(e) {
      e.preventDefault();
      me.setTab($(this).data("tab-target"));
    });
  },
  toggleSidemenu: function() {
    var CLASS_TOGGLE_BUTTON = "js-sidebarToggleBtn";
    var CLASS_CONTENT = "o-content";
    var CLASS_MAIN = "o-main";
    var CLASS_SIDEBAR = "o-sidebar";
    var CLASS_HEADER = "o-header";
    var CLASS_FOOTER = "o-footer";
    var CLASS_ACTIVE = "is-menu-open";
    var CLASS_WILL_CHANGE = "is-will-change";
    $("." + CLASS_TOGGLE_BUTTON)
      .on('click', function() {
        var $this = $(this);
        $this.toggleClass(CLASS_ACTIVE);
        $("." + CLASS_CONTENT).toggleClass(CLASS_ACTIVE);
        $("." + CLASS_MAIN).toggleClass(CLASS_ACTIVE);
        $("." + CLASS_SIDEBAR).toggleClass(CLASS_ACTIVE);
        $("." + CLASS_HEADER).toggleClass(CLASS_ACTIVE);
        $("." + CLASS_FOOTER).toggleClass(CLASS_ACTIVE);
        $("html, body").toggleClass(CLASS_ACTIVE);
      })
      .on('mouseenter', function() {
        $("." + CLASS_CONTENT).addClass(CLASS_WILL_CHANGE);
      })
      .on('mouseleave', function() {
        $("." + CLASS_CONTENT).removeClass(CLASS_WILL_CHANGE);
      });
  },
  buildSortableAddress: function() {
    var me = this;
    var $jsSortable = $(".js-sortable");
    var $form = $("[data-parsley-validate]");
    var $jsAddBtn = $(".js-address-add");

    if (!$jsSortable[0] || !$form[0] || !$jsAddBtn[0]) return;

    var update = function() {
      $jsSortable.children("li").each(function(idx, val) {
        var $this = $(this);
        $this.find(".address-order").val(idx + 1);
        $this.find(".o-contact-setting__body__left__number").text(idx + 1);
      });
    };

    var template = $("#js-address-template").html();
    Mustache.parse(template);
    $jsSortable.sortable({
      scroll: false,
      handle: ".js-sortable__draggable",
      onUpdate: function(e) {
        update();
      }
    });

    //追加ボタン
    $jsAddBtn.on('click', function(e) {
      e.preventDefault();
      var rendered = Mustache.render(template, {});
      $jsSortable.append(rendered);
      $jsSortable.find("li:last-of-type").find("[data-accordion-target]").trigger("click");
      $jsAddBtn.hide();
      update();
    });

    var UpdateEachContents = function($parent) {
      var _name = $parent.find(".js-address-name").val();
      var _phoneNumber = $parent.find(".js-address-phone-number").val();
      $parent
        .find(".address-name")
        .val(_name);
      $parent
        .find(".o-contact-setting__body__left__place")
        .text(_name);
      $parent
        .find(".address-phone-number")
        .val(_phoneNumber);
      $parent
        .find(".o-contact-setting__body__right__phone-number")
        .text(_phoneNumber);
      var $actualPanels = $parent.find(".js-address-panel");
      var $hiddenPanels = $parent.find(".address-panel");
      $actualPanels.each(function(idx, val) {
        $hiddenPanels.eq(idx).val($actualPanels[idx].checked);
      });
    };

    //アコーディオン開閉
    me.$document.on("click", ".o-form [data-accordion-target]", function(e) {
      var $this = $(this);
      if ($this.hasClass('is-active')) {
        var $parent = $this.parents(".js-sortable__content");
        UpdateEachContents($parent);
      }
    });

    //変更を反映
    me.$document.on("click", ".js-address-done", function(e) {
      e.preventDefault();
      var $this = $(this);
      var $parent = $this.parents(".js-sortable__content");
      var groupId = $parent.data("group");
      $form.parsley().validate(groupId);
      if (!$form.parsley().isValid(groupId)) return;
      UpdateEachContents($parent);
      $parent.find("[data-accordion-target]").trigger("click");
    });

    me.$document.on("click", ".js-address-remove", function() {
      var $this = $(this);
      var $parent = $this.parents(".js-sortable__content");
      $parent.remove();
      $jsAddBtn.show();
      update();
    });

  },
  /**
   * accordion
   * data-accordion-target="n"をクリックすると、data-accordion-body="n"をtoggleする
   */
  toggleAccordion: function() {
    var me = this;
    var SELECTOR_ACCORDION_BTN = "[data-accordion-target]";
    var SLIDE_TOGGLE_SPEED = 400;
    var CLASS_ACTIVE = 'is-active';

    $.fn.slideToggleVelocity = function(SLIDE_TOGGLE_SPEED) {
      var $this = $(this);
      if (!$this.hasClass(CLASS_ACTIVE)) {
        $this.velocity("slideDown", {duration: SLIDE_TOGGLE_SPEED});
      } else {
        $this.velocity("slideUp", {duration: SLIDE_TOGGLE_SPEED});
      }
      return this;
    };

    me.$document.on("click", SELECTOR_ACCORDION_BTN, function() {
      var $this = $(this);
      var selectorAccordionBody = "[data-accordion-body='" + $this.data("accordion-target") + "']";
      var $accordionBody = $(selectorAccordionBody);
      $this.toggleClass(CLASS_ACTIVE);
      $accordionBody.slideToggleVelocity(SLIDE_TOGGLE_SPEED).toggleClass(CLASS_ACTIVE);
    });

    me.$document.on("anchored", SELECTOR_ACCORDION_BTN, function() {
      var $this = $(this);
      var selectorAccordionBody = "[data-accordion-body='" + $this.data("accordion-target") + "']";
      var $accordionBody = $(selectorAccordionBody);
      $this.addClass(CLASS_ACTIVE);
      $accordionBody.velocity("slideDown", {duration: SLIDE_TOGGLE_SPEED}).addClass(CLASS_ACTIVE);
    });
  },
  /**
   * tooltip
   * js-tooltipクラスが付いているものについて、data-powertipの内容をクリックで表示
   */
  buildTooltip: function() {
    var me = this;
    var $jsTooltip = $('.js-tooltip');
    if (!$jsTooltip[0]) return;
    if (bowser.tablet || bowser.mobile) {
      $jsTooltip.powerTip({
        placement: 'n',
        // smartPlacement: true,
        // closeDelay: 3000000,
        offset: 18,
        fadeInTime: 150,
        manual: true
      }).each(function() {
        var toolTipMe = this;
        me.$window.on('resize.tooltip', function() {
          $.powerTip.hide(toolTipMe);
        });
        me.$window.on('click.tooltip', function(e) {
          if ($(toolTipMe).has(e.target).length < 1) {
            $.powerTip.hide(toolTipMe);
          }
        });
      }).on('click', function() {
        $.powerTip.toggle(this);
      });
    } else {
      $jsTooltip.powerTip({
        placement: 'n',
        // smartPlacement: true,
        fadeInTime: 150,
        // closeDelay: 3000000,
        offset: 18,
        manual: false
      });
    }
  },
  scrollToTop: function() {
    var SPEED_SCROLL = 300;
    $(".js-page-top").click(function() {
      $('body,html').animate({scrollTop: 0}, SPEED_SCROLL);
    });
  },
  /**
   * ウォークスルーのJS. その他Swiperが必要になった際は共通設定を作ります
   */
  buildSwiper: function() {
    var $btnWrapper = $(".o-fixed-menu");
    var $btnNext = $(".o-slider-button-next");
    var $swiperPagination = $(".swiper-pagination");
    var mySwiper = new Swiper('.swiper-container', {
      pagination: '.swiper-pagination',
      nextButton: '.swiper-button-next',
      prevButton: '.swiper-button-prev',
      centeredSlides: true,
      buttonDisabledClass: "is-disabled",
      allowSwipeToPrev: true,
      slidesPerView: '1',
      breakpoints: {
        767: {
          spaceBetween: 16
        }
      }
    });
  },
  toggleHeaderMenu: function() {
    var me = this;
    var CLASS_ACTIVE = "is-active";
    var CLASS_LOCK = "is-lock";
    var $dropdownBtns = $("[data-dropdown-target]");
    var $dropdownAreas = $("[id^='dropdown-']");

    if (!$dropdownBtns[0] || !$dropdownAreas[0]) return;

    $.fn.showHdrMenu = function() {
      var $me = this;
      $me.css({display: "block", opacity: 0});
      $me.find(".js-ellipsis").trigger("update");
      if (SRCPortal.state.browser.isPCWidth) {
        setTimeout(function() {
          $me.css({display: "none", opacity: "1"}).velocity("slideDown", {duration: 180, easing: "easeInQuad"});
        }, 10); //css追加時間を少しずらして挙動を調整。
      } else {
        setTimeout(function(){
          me.$html.addClass(CLASS_LOCK);
          me.$window.on("resize.hdrMenu", function(){
            if(SRCPortal.state.browser.isPCWidth) {
              me.$window.off(".hdrMenu");
              me.$html.removeClass(CLASS_LOCK);
            }
          });
          $me.css({display: "none", opacity: "1"}).velocity("fadeIn", {duration: 180, easing: "easeInQuad"});
        }, 10); //css追加時間を少しずらして挙動を調整。
      }
      return this;
    };

    $.fn.hideHdrMenu = function() {
      if (SRCPortal.state.browser.isPCWidth) {
        this.velocity("slideUp", {display: "none", duration: 180, easing: "easeInQuad"});
      } else {
        me.$html.removeClass(CLASS_LOCK);
        me.$window.off(".hdrMenu");
        this.velocity("fadeOut", {display: "none", duration: 180, easing: "easeInQuad"});
      }
      return this;
    };


    $dropdownBtns.each(function() {
      var isOpen = false;
      var $this = $(this);
      var $target = $($this.data("dropdown-target"));
      if (!$target[0]) return;
      $this.on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();

        if (!$this.hasClass(CLASS_ACTIVE)) {
          $dropdownBtns.removeClass(CLASS_ACTIVE);
          $dropdownAreas.hideHdrMenu();
          $this.addClass(CLASS_ACTIVE);
          $target.showHdrMenu();

          me.$document.one('click', function closeMenu(e) {
            if ($dropdownAreas.has(e.target).length === 0 || $(e.target).hasClass('o-header__dropdown__close')) {
              $dropdownBtns.removeClass(CLASS_ACTIVE);
              $target.hideHdrMenu();
              isOpen = false;
            } else {
              me.$document.one('click', closeMenu);
            }
          });
        } else {
          $dropdownBtns.removeClass(CLASS_ACTIVE);
          $dropdownAreas.hideHdrMenu();
        }
      });
    });
  },
  toggleModal: function() {
    var CLASS_LOCK = "is-lock";
    var me = this;
    var $modalTarget = $("[data-modal-target]");
    $modalTarget.each(function() {
      var $this = $(this);
      var $modal = $($this.data("modal-target"));
      var $modalClose = $modal.find(".js-modal-close");
      $this.on("click", function(e) {
        e.preventDefault();
        me.$html.addClass(CLASS_LOCK);
        $modal.velocity("fadeIn", {duration: 300, easing: "easeOutExpo"});
        if (!SRCPortal.state.browser.isPCWidth) {
          var $scrollTop = me.$window.scrollTop();
          $('body').css('position', 'fixed').css('top', -$scrollTop);
        }
        $modalClose.on("click.modalClose", function(e) {
          e.preventDefault();
          $modal.velocity("fadeOut", {display: "none", duration: 300, easing: "easeOutExpo"});
          if (!SRCPortal.state.browser.isPCWidth) {
            $('body').css('position', '').css('top', '');
            window.scrollTo(0, $scrollTop);
          }
          $modalClose.off(".modalClose");
          me.$html.removeClass(CLASS_LOCK);
        });
      });
    });

    /**
     * $("#modal-id").modalOpen() でひらけるようにする
     */
    $.fn.modalOpen = function() {
      var $modal = $(this);
      var $modalClose = $modal.find(".js-modal-close");
      me.$html.addClass(CLASS_LOCK);
      $modal.velocity("fadeIn", {duration: 300, easing: "easeOutExpo"});
      $modalClose.on("click.modalClose", function(e) {
        e.preventDefault();
        $modal.velocity("fadeOut", {display: "none", duration: 300, easing: "easeOutExpo"});
        $modalClose.off(".modalClose");
        me.$html.removeClass(CLASS_LOCK);
      });
      return this;
    };

    $.fn.modalClose = function() {
      var $modal = $(this);
      var $modalClose = $modal.find(".js-modal-close");
      $modal.velocity("fadeOut", {display: "none", duration: 300, easing: "easeOutExpo"});
      $modalClose.off(".modalClose"); //他の手段で表示されたmodal対策。
      return this;
    };
  },
  scrollTable: function() {
    var me = this;
    var $tableScroll = $("[data-table-scroll]");
    $tableScroll.floatThead({
      position: 'absolute',
      scrollContainer: true,
      responsiveContainer: true,
      autoReflow: 'true'
    });
    me.$window.on("tabchange", function() {
      $tableScroll.floatThead('reflow');
    });
  },
  /**
   * [data-ahchor-target="x"] クリックで、[data-anchor-body="x"]へスクロール。
   * 飛び先がdata-accordion-bodyをもっているとき、trigger("anchored")
   */
  scrollToAnchor: function() {
    var HEADER_HEIGHT = 70;
    $("[data-anchor-target]").on("click", function(e) {
      var $this = $(this);
      e.preventDefault();
      var id = $this.data("anchor-target");
      var $target = $("[data-anchor-body='" + id + "']");
      if ($target[0]) $target.trigger("anchored");
      $("html,body").animate({
        scrollTop: $target.offset().top - HEADER_HEIGHT
      });
    });
  },
  togglePrintBtnByUserAgent: function() {
    var $jsPrint = $(".js-print");
    if (bowser.mobile || bowser.tablet) {
      $jsPrint.remove();
    } else {
      $jsPrint
        .removeClass("js-print--invisible");
    }
  },
  /**
   * KS_01等。jquery match heightをjsから起動。
   * 通常はdata-mh=""から起動するが、それだと横方向で揃っていない要素の高さは合わせられないため、byRow: falseで動かすためにjs-match-heightで調整できるようにする。
   */
  matchHeight: function() {
    var $jsMatchHeight = $(".js-match-height");
    $jsMatchHeight.matchHeight({
      byRow: false
    });
  }
});

SRCPortal.Form = SRCPortal.Base.extend({
  __construct: function() {
    this.__super.__construct.call(this);
    this.clearInput();
    this.resizeTextArea();
    this.setMaxCheckCount();
    this.setMinCheckCount();
    this.doNumericInput();
    this.changeRequiredByTargetAddress();
    this.toggleMealLogUIBySwitch();
    this.previewImgUpload();
    this.toggleSearchSubmitDisabledByValue();
    this.toggleCheckboxIsCheckedByChecked();
  },
  /**
   * js-clear-input__inputがついているinputの兄弟要素のjs-clear-input__btnを押すと入力内容をclear
   */
  clearInput: function() {
    $(".js-clear-input__btn").each(function(){
      var $btn = $(this);
      var $input = $btn.siblings(".js-clear-input__input");
      if($input.val() !== "") $btn.show();
      $input.on("keyup focusout change input", function(){
        if($input.val() !== "") {
          $btn.show();
        } else {
          $btn.hide();
        }
      });
      $btn.on("click", function(e){
        e.preventDefault();
        $input.val("");
        $btn.hide();
      });
    });
  },
  /**
   * textareaの自動リサイズ
   */
  resizeTextArea: function() {
    var $resizeTarget = $(".js-textarea-autosize");
    if ($resizeTarget[0]){
      autosize($resizeTarget);
    }
  },
  /**
   * data-max-check="n" をラッパー要素につけると、子孫要素のckeckboxにはたらく。
   * n個以上であれば他のものをcheckできないようにする。
   */
  setMaxCheckCount: function() {
    var SELECTOR_TARGET = "[data-max-check]";
    var CLASS_SELECT_NONE = "js-max-check-select-none";
    $(SELECTOR_TARGET).each(function() {
      var $this = $(this);
      var maxCount = parseInt($this.data("max-check"));
      var $inputs = $this.find("input[type=checkbox]");
      var $inputNormal = $inputs
        .filter(function(){
          return !$(this).parent().hasClass(CLASS_SELECT_NONE);
        });
      var $inputSelectNone = $inputs
        .filter(function(){
          return $(this).parent().hasClass(CLASS_SELECT_NONE);
        });
      $inputNormal
        .on("click", function() {
          var $checked = $this.find("input[type=checkbox]:checked");
          var $notChecked = $inputNormal.not(':checked');
          //チェックが3つ付いたら、チェックされてないチェックボックスにdisabledを加える
          if ($checked.length >= maxCount) {
            $notChecked.attr("disabled", true);
          } else {
            //3つ以下ならdisabledを外す
            $notChecked.attr("disabled", false);
          }
          $inputSelectNone.prop("checked", false).trigger("change");
        });
      $inputSelectNone
        .on("click", function(){
          var $input = $(this);
          if($input.prop("checked")) {
            $inputNormal.attr("disabled", false).prop("checked", false).trigger("change");
          }
        });

    });
  },

  setMinCheckCount: function() {
    var SELECTOR_TARGET = "[data-min-check]";
    $(SELECTOR_TARGET).each(function() {
      var $this = $(this);
      var minCount = parseInt($this.data("min-check"));
      var check = function(that) {
        var $count = $("input[type=checkbox]:checked").length;
        var $not = $('input[type=checkbox]').not(':checked');
        //チェックが3つ付いたら、チェックされてないチェックボックスにdisabledを加える
        if ($count < minCount) {
          $(that).closest("form").find('[type=submit]').attr("disabled", true);
        } else {
          //3つ以下ならisabledを外す
          $(that).closest("form").find('[type=submit]').attr("disabled", false);
        }
      };
      $this.find("input[type=checkbox]").click(function() {
        check(this);
      });
      check(this);
    });
  },
  doNumericInput: function() {
    var $jsNumericInputs = $(".js-numeric-input");
    $jsNumericInputs.each(function() {
      var $jsNumericInput = $(this);
      var $input = $jsNumericInput.find("input");
      var maxNum = Number($input.attr('max'));
      var minNum = Number($input.attr('min'));
      var inputNum = Number($input.val());

      // setIntervalの繰り返し時間間隔（ms）
      var TIME_INTERVAL = 100;

      // 何msボタンを長押ししたらcalc()を呼び出す（連続入力が開始される）かを指定する値
      var TIME_CALCSTART = 500;

      var $btns = $jsNumericInput.find('.m-numeric-input__btn--add, .m-numeric-input__btn--sub');

      var calc = function(num) {
        inputNum = Number($input.val());
        inputNum += num;
        if (inputNum >= maxNum) {
          inputNum = maxNum;
        }
        if (inputNum <= minNum) {
          inputNum = minNum;
        }
        $input.val(inputNum);
        $input.parsley().validate();
        return false;
      };

      $btns.each(function() {
        var $btn = $(this);
        var addNum = Number($btn.attr('data-numeric-add'));
        var time = null;
        var _interval = null;
        $btn
          .on("mousedown touchstart", function(e) {
            if (e.button === 0 || e.type === "touchstart") {
              time = 0;
              _interval = setInterval(function() {
                time += TIME_INTERVAL;
                if (time >= TIME_CALCSTART) {
                  calc(addNum);
                }
              }, TIME_INTERVAL);
              calc(addNum);
            }
          })
          .on("mouseup mouseleave touchend touchleave", function() {
            clearInterval(_interval);
          });
      });
    });
  },
  /**
   * ST_03 連絡先設定によって必須項目を切り替える。
   * input[type=radio]にdata-change-require-target="xxx"をつけ、
   * 対象フォームのラッパー要素にdata-change-require-body="xxx"をつける。
   * data-change-require-target="xxx"が選択された時、data-change-require-body="xxx"のなかの項目が必須扱いになり、
   * data-change-require-body="xxx"以外の項目が非必須になる。xxxはhome, workを仮でつけた。
   */
  changeRequiredByTargetAddress: function() {
    var $trigger = $("[data-change-require-target]");
    var $target = $("[data-change-require-body]");
    var $form = $("[data-parsley-validate]");

    var setRequiredByTargetName = function(name) {
      $target
        .filter(function() {
          return $(this).data("change-require-body") !== name;
        })
        .find("input, select")
        .attr("required", false)
        .end()
        .find(".a-label")
        .hide()
        .end()
        .end()
        .filter(function() {
          return $(this).data("change-require-body") === name;
        })
        .find("input, select")
        .filter(function() {
          return !$(this).data("no-required");
        })
        .attr("required", true)
        .end()
        .end()
        .find(".a-label")
        .show()
        .end()
        .end();
    };

    $trigger.on("change", function() {
      var name = $(this).data("change-require-target");
      setRequiredByTargetName(name);
      $form.parsley().reset();
    }).filter(":checked").each(function() {
      var name = $(this).data("change-require-target");
      setRequiredByTargetName(name);
    });
  },
  /**
   * LR_04 食べた・食べてないの切り替えでUIが出たり出なかったりするように。
   */
  toggleMealLogUIBySwitch: function() {
    var $target = $(".m-meal-box--health-record");
    $target.each(function() {
      var $this = $(this);
      var $checkbox = $this.find("input[type='checkbox']");
      var $body = $this.find(".m-meal-box__body");
      var CLASS_SHOWING = "is-showing";
      var CLASS_HIDDEN = "is-hidden";
      $checkbox.on("change", function() {
        var isChecked = $(this).prop("checked");
        if (isChecked) {
          $body.removeClass(CLASS_HIDDEN).addClass(CLASS_SHOWING);
        } else {
          $body.removeClass(CLASS_SHOWING).addClass(CLASS_HIDDEN);
        }
      }).each(function() {
        var isChecked = $(this).prop("checked");
        if (isChecked) {
          $body.removeClass(CLASS_HIDDEN).addClass(CLASS_SHOWING);
        } else {
          $body.removeClass(CLASS_SHOWING).addClass(CLASS_HIDDEN);
        }
      });
    });
  },
  previewImgUpload: function() {
    var $target = $('.js-img-upload');

    $target.each(function() {
      var $this = $(this);
      var $bt = $this.find('.js-img-upload__btn');
      var $body = $this.find('.js-img-upload__body');
      var $img = $this.find('.js-img-upload__img');
      var $remove = $this.find(".js-img-upload-remove");
      var $imgBody = $img.find("img");
      $bt.on('change', function(e) {
        var file = e.target.files[0];
        if (!file) {
          return;
        }
        if (window.createObjectURL) {
          var url = window.createObjectURL(file);
          $imgBody.attr("src", url);
          $body.hide();
          $img.show();
        } else {
          var filereader = new FileReader();
          filereader.onload = function(e) {
            var url = e.target.result;
            $imgBody.attr("src", url);
            $body.hide();
            $img.show();
          };
          filereader.readAsDataURL(file);
        }
      });
      $remove.on("click", function(e) {
        e.preventDefault();
        $img.hide();
        $body.show();
        $bt.val("");
      });
    });
    return this;
  },
  toggleSearchSubmitDisabledByValue: function() {
    var $searchBoxWrapper = $(".js-search-box");
    var $searchBox = $searchBoxWrapper.find("input[type='search']");
    var $searchBtn = $searchBoxWrapper.find(".js-search-box__submit");
    var $searchBoxData = $searchBox.val();
    if ($searchBoxData === "") {
      $searchBtn.attr('disabled', 'disabled');
    }
    $searchBox.on(Parsley.options.trigger, function() {
      var $searchBoxData = $searchBox.val();
      if ($searchBoxData === "") {
        $searchBtn.attr('disabled', 'disabled');
      } else {
        $searchBtn.attr('disabled', false);
      }
    });
  },
  toggleCheckboxIsCheckedByChecked: function() {
    var me = this;
    var check = function(that) {
      var $this = $(that);
      var $body = $this
        .parents(".a-input-switch, .a-input-checkpanel")
        .find(".a-input-switch__body, .a-input-checkpanel__label");
      var CLASS_CHECKED = "is-checked";
      if ($this.is(':checked')) {
        $body.addClass(CLASS_CHECKED);
      } else {
        $body.removeClass(CLASS_CHECKED);
      }
    };
    me.$document.on("change", ".a-input-switch input[type='checkbox'], .a-input-checkpanel input[type='checkbox']", function(e) {
      check(this);
    });
    $(".a-input-switch input[type='checkbox'], .a-input-checkpanel input[type='checkbox']").each(function(){
      check(this);
    });

  }
});

SRCPortal.Lottery = SRCPortal.Base.extend({
  __construct: function() {
    this.__super.__construct.call(this);
    this.doLottery();
  },
  doLottery: function() {
    var $lotteryBtn = $(".js-btn-lottery");
    var $lotteryModal = $("#modal-lottery");
    var $lotteryStart = $lotteryModal.find(".js-lottery-start");
    var $lotteryStartModal = $lotteryModal.find(".js-lottery-start-modal");
    var $lotteryWinModal = $lotteryModal.find(".js-lottery-win-modal");
    var $lotteryLoseModal = $lotteryModal.find(".js-lottery-lose-modal");
    var $lotteryAnimeModal = $lotteryModal.find(".js-lottery-anime-modal");
    var $lotteryTimes = $lotteryStartModal.find(".js-lottery-times");
    var $lotteryClose = $(".js-modal-close-lottery");
    var $lotteryRetry = $lotteryWinModal.find($(".js-lottery-retry"));
    var $lotteryTimesNumber = Number($lotteryTimes.text());
    var API_URL = SRCPortal.CONST.API_REWARD;
    var _isImgLoaded = false;
    $lotteryWinModal.css("display", "none");
    $lotteryLoseModal.css("display", "none");
    $lotteryAnimeModal.css("display", "none");

    $lotteryStart.on("click", function(e) {
      e.preventDefault();
      var $this = $(this);

      $lotteryTimesNumber--;
      $this.css("pointer-events", "none");

      var imgLoadStart = function(){
        // http://cly7796.net/wp/javascript/do-treatment-after-image-loading/
        var IMAGE_PATH = "/assets/img/animation-lottery.png";
        var d = new $.Deferred();
        var img = $('<img>');
        img.on('load', function() { //load complete handler
          d.resolve();
        });
        img.attr('src', IMAGE_PATH); //load start
        return d.promise();
      };

      var lotteryAnime = function() {
        var d = new $.Deferred();
        var $animation = $lotteryModal.find(".a-lottery-animation");
        var frames = [0, 8, 17, 28];
        var frame = frames[Math.floor(Math.random() * 4)];
        $animation.attr("class", "a-lottery-animation a-lottery-animation--start-frame-" + frame);
        $lotteryStartModal.velocity("fadeOut", {
          display: "none", duration: 100, easing: "ease", complete: function() {
            //This shows animation modal. It may be more beautiful to not do fade
            //velocity.js http://velocityjs.org/
            $lotteryAnimeModal.velocity("fadeIn", {duration: 100, easing: "ease"});

            var DURATION_OF_ANIMATION = 380 * 8.5; //milisecond
            setTimeout(function(){
              d.resolve(); //go next step(jquery.deffered)
            }, DURATION_OF_ANIMATION);
          }
        });
        return d.promise();
      };

      var apiCall = function() {
        return $.ajax({
          url: API_URL,
          method: 'GET',
          success: function(data) {}
        });
      };

      var closeAnime = function(data) {
        var d = new $.Deferred();
        $lotteryAnimeModal.velocity("fadeOut", {display: "none", duration: 100, easing: "ease"});
        $lotteryTimes.text(String($lotteryTimesNumber));
        d.resolve(data);
        return d.promise();
      };

      var resultAnnouncement = function(data) {
        var d = new $.Deferred();
        if (data.isWin === true) {
          $lotteryWinModal.velocity("fadeIn", {duration: 100, delay: 400, easing: "ease"});
          d.resolve();
        } else {
          $lotteryLoseModal.velocity("fadeIn", {duration: 100, delay: 400, easing: "ease"});
          d.resolve();
        }
        $this.css("pointer-events", "");
        return d.promise();
      };

      var btnDisabled = function() {
        if ($lotteryTimesNumber === 0) {
          $lotteryBtn.replaceWith('<p class="a-text-14">終了しました</p>');
          $lotteryRetry.closest(".o-grid-row").addClass("u-dn");
        }
      };

      var def = $.Deferred(function(d) {

        d
          .then(imgLoadStart)
          .then(lotteryAnime)
          .then(apiCall)
          .then(closeAnime)
          .then(resultAnnouncement)
          .then(btnDisabled);
      });
      def.resolve();
    });

    $lotteryClose.on("click", function(e) {
      e.preventDefault();
      var $this = $(this);
      var lotteryModalClose = function() {
        var d = new $.Deferred();
        $lotteryModal.modalClose();
        d.resolve();
        return d.promise();
      };

      var lotteryModalReset = function() {
        var d = new $.Deferred();
        var $currentModal = $this.closest(".o-modal__inner");
        $currentModal.css("display", "none");
        $lotteryStartModal.css("display", "").css("opacity", "1");
        d.resolve();
        return d.promise();
      };

      var def = $.Deferred(function(d) {
        d.then(lotteryModalClose).then(lotteryModalReset);
      });
      def.resolve();
    });

    $lotteryRetry.on("click", function(e) {
      e.preventDefault();
      $lotteryWinModal.velocity("fadeOut", {
        display: "none", duration: 100, easing: "ease", complete: function() {
          $lotteryStartModal.velocity("fadeIn", {duration: 100, easing: "ease"});
        }
      });
    });
  }
});

$(function() {
  new SRCPortal.Init();
  new SRCPortal.Common();
  new SRCPortal.Chart();
  new SRCPortal.MealRecord();
  new SRCPortal.UI();
  new SRCPortal.Form();
  new SRCPortal.Lottery();
});

