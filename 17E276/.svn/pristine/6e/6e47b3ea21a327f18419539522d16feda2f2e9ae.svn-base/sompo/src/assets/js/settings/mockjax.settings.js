/* global SRCPortal */

/**
 * mockjaxによるスタブ設定
 * responseTime設定で実際の挙動に近づける
 * NOTE: API疎通後このコードは除去すること。
 */

$.mockjax({
  url: SRCPortal.CONST.API_EATSMART,
  responseTime: 500,
  responseText: {
    status: "success",
  }
});

$.mockjax({
  url: SRCPortal.CONST.API_REWARD,
  responseTime: 500,
  responseText: {
    status: "success",
    isWin: !!Math.round(Math.random())
  }
});
