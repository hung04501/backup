/* global Chart */

/**
 * chart.jsのSOMPO専用プラグイン等をこちらで設定する。
 */


(function(){
  //helpersを使う処理のための準備
  var helpers = Chart.helpers;

  function lineEnabled(dataset, options) {
    return helpers.valueOrDefault(dataset.showLine, options.showLines);
  }

  /**
   * グラフのシャドウ(Chart.controllers.line.drawを上書き)
   */
  var draw = Chart.controllers.line.prototype.draw;
  Chart.controllers.line = Chart.controllers.line.extend({
    draw: function() {
      var ctx = this.chart.chart.ctx;

      var me = this;
      var chart = me.chart;
      var meta = me.getMeta();
      var points = meta.data || [];
      var area = chart.chartArea;
      var ilen = points.length;
      var i = 0;

      // helpers.canvas.clipArea(chart.ctx, area);

      if (lineEnabled(me.getDataset(), chart.options)) {
        ctx.save();
        ctx.shadowColor = meta.dataset._view.borderColor;
        ctx.globalAlpha = 0.5;
        ctx.shadowBlur = 8;
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 12;
        meta.dataset.draw();
        ctx.restore();
      }
      helpers.canvas.unclipArea(chart.ctx);

      // Draw the points
      for (; i < ilen; ++i) {
        points[i].draw(area);
      }

    }
  });


  /**
   * 背景色
   * options.chartArea.backgroundColorで背景色を設定可能にする。
   */
  Chart.pluginService.register({
    beforeDraw: function(chart, easing) {
      if (chart.config.options.chartArea && chart.config.options.chartArea.backgroundColor) {
        var helpers = Chart.helpers;
        var ctx = chart.chart.ctx;
        var chartArea = chart.chartArea;
        ctx.save();
        ctx.fillStyle = chart.config.options.chartArea.backgroundColor;
        ctx.fillRect(chartArea.left, chartArea.top, chartArea.right - chartArea.left, chartArea.bottom - chartArea.top);
        ctx.restore();
      }
    }
  });

  /**
   * データ見出し
   * KS_02でつねに表示
   */
  Chart.plugins.register({
    afterDatasetsDraw: function(chart, easing) {
      // To only draw at the end of animation, check for easing === 1
      var ctx = chart.ctx;

      chart.data.datasets.forEach(function(dataset, i) {
        var meta = chart.getDatasetMeta(i);
        if (dataset.isShowLabel) {
          meta.data.forEach(function(element, index) {
            if (dataset.data[index] === null) return;

            var fontSize = 18;
            var fontStyle = 'bold';
            var fontFamily = 'Yantramanav';
            ctx.font = Chart.helpers.fontString(fontSize, fontStyle, fontFamily);

            //小数点以下の表示処理
            var dataString = "";
            if(dataset.decimalDigits) {
              dataString = dataset.data[index].toFixed(dataset.decimalDigits);
            } else {
              dataString = dataset.data[index].toString();
            }





            // Make sure alignment settings are correct
            if(index === 0) {
              ctx.textAlign = 'left';
            } else if (index !== meta.data.length - 1){
              ctx.textAlign = 'center';
            } else {
              ctx.textAlign = 'right';
            }
            ctx.textBaseline = 'middle';

            ctx.lineWidth = 3.0;
            var padding = 6;
            var position = element.tooltipPosition();


            ctx.save();
            ctx.shadowColor = "rgba(0,0,0,0.05)";
            ctx.shadowBlur = 8;
            ctx.shadowOffsetX = 0;
            ctx.shadowOffsetY = 10;
            ctx.strokeStyle = "#ffffff";
            ctx.strokeText(dataString, position.x, position.y - (fontSize / 2) - padding);
            ctx.restore();

            ctx.fillStyle = dataset.labelColor[index];
            ctx.fillText(dataString, position.x, position.y - (fontSize / 2) - padding);

            ctx.fillStyle = "white";
          });
        }
      });
    }
  });

  /**
   * ツールチップ強制表示
   */
  Chart.pluginService.register({
    afterDraw: function(chart, easing) {
      if (chart.config.options.showLatestTooltip) {
        // we don't want the permanent tooltips to animate, so don't do anything till the animation runs atleast once
        if (!chart.initialized) {
          if (easing !== 1) {
            return;
          }

          chart.config.data.datasets.forEach(function(val, idx){
            if(val.isBody){
              if(chart.tooltip._active === undefined) {
                chart.tooltip._active = [];
              }
              var activeElements = chart.tooltip._active;
              var requestedElem = chart.getDatasetMeta(idx).data[chart.getDatasetMeta(idx).data.length - 1];
              for(var i = 0; i < activeElements.length; i++) {
                if(requestedElem._datasetIndex === activeElements[i]._datasetIndex) {
                  return;
                }
              }
              activeElements.push(requestedElem);
              chart.tooltip._active = activeElements;
              chart.tooltip.update(true);
              chart.draw();
            }
          });

          chart.initialized = true;
        }
      }
    }
  });


  /**
   * HTML tooltip
   */
  Chart.defaults.global.hover.custom = function(tooltipModel){
    var _this = this;
    if(!tooltipModel.dataPoints) return;

    // Tooltip Element
    tooltipModel.dataPoints.forEach(function(val, idx){
      var _datasetIndex = tooltipModel.dataPoints[idx].datasetIndex;
      var _dataIndex = tooltipModel.dataPoints[idx].index;
      if(!_this._data.datasets[_datasetIndex].labelColor) return;

      var tooltipEl = _this._tooltipEl ? _this._tooltipEl[idx] : false;

      // Create element on first render
      if (!tooltipEl) {
        tooltipEl = document.createElement('div');
        tooltipEl.id = 'chartjs-tooltip--' + Math.random().toString(36).substr(2, 10);
        tooltipEl.className = 'a-chart-line__tooltip';
        _this._chart.canvas.parentElement.appendChild(tooltipEl);
        if(!_this._tooltipEl){
          _this._tooltipEl = [];
        }
        _this._tooltipEl[idx] = tooltipEl;
      }

      // Hide if no tooltip
      if (tooltipModel.opacity === 0) {
        tooltipEl.style.opacity = 0;
        return;
      }

      // Set caret Position
      tooltipEl.classList.remove('above');
      tooltipEl.classList.remove('below');
      tooltipEl.classList.remove('no-transform');
      if (tooltipModel.yAlign) {
        tooltipEl.classList.add(tooltipModel.yAlign);
      } else {
        tooltipEl.classList.add('no-transform');
      }

      tooltipEl.classList.remove('is-first');
      tooltipEl.classList.remove('is-last');
      if(_dataIndex === 0) {
        tooltipEl.classList.add('is-first');
      } else if (_dataIndex === _this._data.datasets[_datasetIndex].data.length - 1){
        tooltipEl.classList.add('is-last');
      }

      tooltipEl.classList.add('is-with-point');


      function getBody(val) {
        var dataString = val.split(" ")[1];
        if(_this._data.datasets[_datasetIndex].decimalDigits) {
          dataString = parseFloat(dataString).toFixed(_this._data.datasets[_datasetIndex].decimalDigits);
        } else if (_this._data.datasets[_datasetIndex].yAxisType === "time"){
          var _label = parseInt(dataString, 10);
          var _h = Math.floor(_label / 60);
          var _m = (_label / 60 - _h) * 60;
          dataString = String(_h) + ":" + ("00" + String(_m)).slice(-2);
        } else {
          dataString = dataString.toString();
        }
        return dataString;
      }

      // Set Text
      if (tooltipModel.body) {
        var titleLines = tooltipModel.title || [];

        var innerHtml = '';

        var color = _this._data.datasets[_datasetIndex].labelColor[_dataIndex];
        innerHtml += '<div style="color: ' + color + '">' + getBody(tooltipModel.body[idx].lines[0]) + '</div>';

        tooltipEl.innerHTML = innerHtml;
      }

      // `this` will be the overall tooltip
      var position = $(_this._chart.canvas).offset();

      // Display, position, and set styles for font
      tooltipEl.style.opacity = 1;
      tooltipEl.style.left = tooltipModel.dataPoints[idx].x + 'px';
      tooltipEl.style.top = tooltipModel.dataPoints[idx].y + 'px';

    });

  };

  /**
   * Sompo専用X軸描画
   * 最後のgridlineを最初のgridlineと同じ色に。
   */

  function parseFontOptions(options) {
    var valueOrDefault = helpers.valueOrDefault;
    var globalDefaults = Chart.defaults.global;
    var size = valueOrDefault(options.fontSize, globalDefaults.defaultFontSize);
    var style = valueOrDefault(options.fontStyle, globalDefaults.defaultFontStyle);
    var family = valueOrDefault(options.fontFamily, globalDefaults.defaultFontFamily);

    return {
      size: size,
      style: style,
      family: family,
      font: helpers.fontString(size, style, family)
    };
  }

  var SRCPortalXAxis = Chart.scaleService.getScaleConstructor('category').extend({
    draw: function(chartArea) {
      var me = this;
      var options = me.options;
      if (!options.display) {
        return;
      }

      var context = me.ctx;
      var globalDefaults = Chart.defaults.global;
      var optionTicks = options.ticks.minor;
      var optionMajorTicks = options.ticks.major || optionTicks;
      var gridLines = options.gridLines;
      var scaleLabel = options.scaleLabel;

      var isRotated = me.labelRotation !== 0;
      var skipRatio;
      var useAutoskipper = optionTicks.autoSkip;
      var isHorizontal = me.isHorizontal();

      // figure out the maximum number of gridlines to show
      var maxTicks;
      if (optionTicks.maxTicksLimit) {
        maxTicks = optionTicks.maxTicksLimit;
      }

      var tickFontColor = helpers.valueOrDefault(optionTicks.fontColor, globalDefaults.defaultFontColor);
      var tickFont = parseFontOptions(optionTicks);
      var majorTickFontColor = helpers.valueOrDefault(optionMajorTicks.fontColor, globalDefaults.defaultFontColor);
      var majorTickFont = parseFontOptions(optionMajorTicks);

      var tl = gridLines.drawTicks ? gridLines.tickMarkLength : 0;

      var scaleLabelFontColor = helpers.valueOrDefault(scaleLabel.fontColor, globalDefaults.defaultFontColor);
      var scaleLabelFont = parseFontOptions(scaleLabel);

      var labelRotationRadians = helpers.toRadians(me.labelRotation);
      var cosRotation = Math.cos(labelRotationRadians);
      var longestRotatedLabel = me.longestLabelWidth * cosRotation;

      var itemsToDraw = [];

      if (isHorizontal) {
        skipRatio = false;

        if ((longestRotatedLabel + optionTicks.autoSkipPadding) * me.ticks.length > (me.width - (me.paddingLeft + me.paddingRight))) {
          skipRatio = 1 + Math.floor(((longestRotatedLabel + optionTicks.autoSkipPadding) * me.ticks.length) / (me.width - (me.paddingLeft + me.paddingRight)));
        }

        // if they defined a max number of optionTicks,
        // increase skipRatio until that number is met
        if (maxTicks && me.ticks.length > maxTicks) {
          while (!skipRatio || me.ticks.length / (skipRatio || 1) > maxTicks) {
            if (!skipRatio) {
              skipRatio = 1;
            }
            skipRatio += 1;
          }
        }

        if (!useAutoskipper) {
          skipRatio = false;
        }
      }


      var xTickStart = options.position === 'right' ? me.left : me.right - tl;
      var xTickEnd = options.position === 'right' ? me.left + tl : me.right;
      var yTickStart = options.position === 'bottom' ? me.top : me.bottom - tl;
      var yTickEnd = options.position === 'bottom' ? me.top + tl : me.bottom;

      helpers.each(me.ticks, function(tick, index) {
        var label = (tick && tick.value) || tick;
        // If the callback returned a null or undefined value, do not draw this line
        if (helpers.isNullOrUndef(label)) {
          return;
        }

        var isLastTick = me.ticks.length === index + 1;

        // Since we always show the last tick,we need may need to hide the last shown one before
        var shouldSkip = (skipRatio > 1 && index % skipRatio > 0) || (index % skipRatio === 0 && index + skipRatio >= me.ticks.length);
        if (shouldSkip && !isLastTick || helpers.isNullOrUndef(label)) {
          return;
        }

        var lineWidth, lineColor, borderDash, borderDashOffset;
        if (index === (typeof me.zeroLineIndex !== 'undefined' ? me.zeroLineIndex : 0)) {
          // Draw the first index specially
          lineWidth = gridLines.zeroLineWidth;
          lineColor = gridLines.zeroLineColor;
          borderDash = gridLines.zeroLineBorderDash;
          borderDashOffset = gridLines.zeroLineBorderDashOffset;
        } else {
          lineWidth = helpers.valueAtIndexOrDefault(gridLines.lineWidth, index);
          lineColor = helpers.valueAtIndexOrDefault(gridLines.color, index);
          borderDash = helpers.valueOrDefault(gridLines.borderDash, globalDefaults.borderDash);
          borderDashOffset = helpers.valueOrDefault(gridLines.borderDashOffset, globalDefaults.borderDashOffset);
        }

        // Common properties
        var tx1, ty1, tx2, ty2, x1, y1, x2, y2, labelX, labelY;
        var textAlign = 'middle';
        var textBaseline = 'middle';
        var tickPadding = optionTicks.padding;

        if (isHorizontal) {
          var labelYOffset = tl + tickPadding;

          if (options.position === 'bottom') {
            // bottom
            textBaseline = !isRotated ? 'top' : 'middle';
            textAlign = !isRotated ? 'center' : 'right';
            labelY = me.top + labelYOffset;
          } else {
            // top
            textBaseline = !isRotated ? 'bottom' : 'middle';
            textAlign = !isRotated ? 'center' : 'left';
            labelY = me.bottom - labelYOffset;
          }

          var xLineValue = me.getPixelForTick(index) + helpers.aliasPixel(lineWidth); // xvalues for grid lines
          labelX = me.getPixelForTick(index, gridLines.offsetGridLines) + optionTicks.labelOffset; // x values for optionTicks (need to consider offsetLabel option)

          tx1 = tx2 = x1 = x2 = xLineValue;
          ty1 = yTickStart;
          ty2 = yTickEnd;
          y1 = chartArea.top;
          y2 = chartArea.bottom;
        } else {
          var isLeft = options.position === 'left';
          var labelXOffset;

          if (optionTicks.mirror) {
            textAlign = isLeft ? 'left' : 'right';
            labelXOffset = tickPadding;
          } else {
            textAlign = isLeft ? 'right' : 'left';
            labelXOffset = tl + tickPadding;
          }

          labelX = isLeft ? me.right - labelXOffset : me.left + labelXOffset;

          var yLineValue = me.getPixelForTick(index); // xvalues for grid lines
          yLineValue += helpers.aliasPixel(lineWidth);
          labelY = me.getPixelForTick(index, gridLines.offsetGridLines) + optionTicks.labelOffset;

          tx1 = xTickStart;
          tx2 = xTickEnd;
          x1 = chartArea.left;
          x2 = chartArea.right;
          ty1 = ty2 = y1 = y2 = yLineValue;
        }

        itemsToDraw.push({
          tx1: tx1,
          ty1: ty1,
          tx2: tx2,
          ty2: ty2,
          x1: x1,
          y1: y1,
          x2: x2,
          y2: y2,
          labelX: labelX,
          labelY: labelY,
          glWidth: lineWidth,
          glColor: lineColor,
          glBorderDash: borderDash,
          glBorderDashOffset: borderDashOffset,
          rotation: -1 * labelRotationRadians,
          label: label,
          major: tick.major,
          textBaseline: textBaseline,
          textAlign: textAlign
        });
      });

      // Draw all of the tick labels, tick marks, and grid lines at the correct places
      helpers.each(itemsToDraw, function(itemToDraw) {
        if (gridLines.display) {
          context.save();
          context.lineWidth = itemToDraw.glWidth;
          context.strokeStyle = itemToDraw.glColor;
          if (context.setLineDash) {
            context.setLineDash(itemToDraw.glBorderDash);
            context.lineDashOffset = itemToDraw.glBorderDashOffset;
          }

          context.beginPath();

          if (gridLines.drawTicks) {
            context.moveTo(itemToDraw.tx1, itemToDraw.ty1);
            context.lineTo(itemToDraw.tx2, itemToDraw.ty2);
          }

          if (gridLines.drawOnChartArea) {
            context.moveTo(itemToDraw.x1, itemToDraw.y1);
            context.lineTo(itemToDraw.x2, itemToDraw.y2);
          }

          context.stroke();
          context.restore();
        }

        if (optionTicks.display) {
          // Make sure we draw text in the correct color and font
          context.save();
          context.translate(itemToDraw.labelX, itemToDraw.labelY);
          context.rotate(itemToDraw.rotation);
          context.font = itemToDraw.major ? majorTickFont.font : tickFont.font;
          context.fillStyle = itemToDraw.major ? majorTickFontColor : tickFontColor;
          context.textBaseline = itemToDraw.textBaseline;
          context.textAlign = itemToDraw.textAlign;

          var label = itemToDraw.label;
          if (helpers.isArray(label)) {
            for (var i = 0, y = 0; i < label.length; ++i) {
              // We just make sure the multiline element is a string here..
              context.fillText('' + label[i], 0, y);
              // apply same lineSpacing as calculated @ L#320
              y += (tickFont.size * 1.5);
            }
          } else {
            context.fillText(label, 0, 0);
          }
          context.restore();
        }
      });

      if (scaleLabel.display) {
        // Draw the scale label
        var scaleLabelX;
        var scaleLabelY;
        var rotation = 0;
        var halfLineHeight = helpers.valueOrDefault(scaleLabel.lineHeight, scaleLabelFont.size) / 2;

        if (isHorizontal) {
          scaleLabelX = me.left + ((me.right - me.left) / 2); // midpoint of the width
          scaleLabelY = options.position === 'bottom' ? me.bottom - halfLineHeight : me.top + halfLineHeight;
        } else {
          var isLeft = options.position === 'left';
          scaleLabelX = isLeft ? me.left + halfLineHeight : me.right - halfLineHeight;
          scaleLabelY = me.top + ((me.bottom - me.top) / 2);
          rotation = isLeft ? -0.5 * Math.PI : 0.5 * Math.PI;
        }

        context.save();
        context.translate(scaleLabelX, scaleLabelY);
        context.rotate(rotation);
        context.textAlign = 'center';
        context.textBaseline = 'middle';
        context.fillStyle = scaleLabelFontColor; // render in correct colour
        context.font = scaleLabelFont.font;
        context.fillText(scaleLabel.labelString, 0, 0);
        context.restore();
      }

      if (gridLines.drawBorder) {
        // Draw the line at the edge of the axis
        context.lineWidth = helpers.valueAtIndexOrDefault(gridLines.lineWidth, 0);
        context.strokeStyle = helpers.valueAtIndexOrDefault(gridLines.color, 0);
        var x1 = me.left,
          x2 = me.right,
          y1 = me.top,
          y2 = me.bottom;

        var aliasPixel = helpers.aliasPixel(context.lineWidth);
        if (isHorizontal) {
          y1 = y2 = options.position === 'top' ? me.bottom : me.top;
          y1 += aliasPixel;
          y2 += aliasPixel;
        } else {
          x1 = x2 = options.position === 'left' ? me.right : me.left;
          x1 += aliasPixel;
          x2 += aliasPixel;
        }

        context.beginPath();
        context.moveTo(x1, y1);
        context.lineTo(x2, y2);
        context.stroke();
      }
    }
  });

  Chart.scaleService.registerScaleType('SRCPortalXAxis', SRCPortalXAxis, {position: 'bottom'});

  /**
   * Sompo専用Y軸描画
   * 見出しを数字の上に
   */
  var SRCPortalYAxis = Chart.scaleService.getScaleConstructor('linear').extend({
    draw: function(chartArea) {
      var me = this;
      var options = me.options;
      if (!options.display) {
        return;
      }

      var context = me.ctx;
      var globalDefaults = Chart.defaults.global;
      var optionTicks = options.ticks.minor;
      var optionMajorTicks = options.ticks.major || optionTicks;
      var gridLines = options.gridLines;
      var scaleLabel = options.scaleLabel;

      var isRotated = me.labelRotation !== 0;
      var skipRatio;
      var useAutoskipper = optionTicks.autoSkip;
      var isHorizontal = me.isHorizontal();

      // figure out the maximum number of gridlines to show
      var maxTicks;
      if (optionTicks.maxTicksLimit) {
        maxTicks = optionTicks.maxTicksLimit;
      }

      var tickFontColor = helpers.valueOrDefault(optionTicks.fontColor, globalDefaults.defaultFontColor);
      var tickFont = parseFontOptions(optionTicks);
      var majorTickFontColor = helpers.valueOrDefault(optionMajorTicks.fontColor, globalDefaults.defaultFontColor);
      var majorTickFont = parseFontOptions(optionMajorTicks);

      var tl = gridLines.drawTicks ? gridLines.tickMarkLength : 0;

      var scaleLabelFontColor = helpers.valueOrDefault(scaleLabel.fontColor, globalDefaults.defaultFontColor);
      var scaleLabelFont = parseFontOptions(scaleLabel);

      var labelRotationRadians = helpers.toRadians(me.labelRotation);
      var cosRotation = Math.cos(labelRotationRadians);
      var longestRotatedLabel = me.longestLabelWidth * cosRotation;

      var itemsToDraw = [];

      if (isHorizontal) {
        skipRatio = false;

        if ((longestRotatedLabel + optionTicks.autoSkipPadding) * me.ticks.length > (me.width - (me.paddingLeft + me.paddingRight))) {
          skipRatio = 1 + Math.floor(((longestRotatedLabel + optionTicks.autoSkipPadding) * me.ticks.length) / (me.width - (me.paddingLeft + me.paddingRight)));
        }

        // if they defined a max number of optionTicks,
        // increase skipRatio until that number is met
        if (maxTicks && me.ticks.length > maxTicks) {
          while (!skipRatio || me.ticks.length / (skipRatio || 1) > maxTicks) {
            if (!skipRatio) {
              skipRatio = 1;
            }
            skipRatio += 1;
          }
        }

        if (!useAutoskipper) {
          skipRatio = false;
        }
      }


      var xTickStart = options.position === 'right' ? me.left : me.right - tl;
      var xTickEnd = options.position === 'right' ? me.left + tl : me.right;
      var yTickStart = options.position === 'bottom' ? me.top : me.bottom - tl;
      var yTickEnd = options.position === 'bottom' ? me.top + tl : me.bottom;

      helpers.each(me.ticks, function(tick, index) {
        var label = (tick && tick.value) || tick;
        // If the callback returned a null or undefined value, do not draw this line
        if (helpers.isNullOrUndef(label)) {
          return;
        }

        var isLastTick = me.ticks.length === index + 1;

        // Since we always show the last tick,we need may need to hide the last shown one before
        var shouldSkip = (skipRatio > 1 && index % skipRatio > 0) || (index % skipRatio === 0 && index + skipRatio >= me.ticks.length);
        if (shouldSkip && !isLastTick || helpers.isNullOrUndef(label)) {
          return;
        }

        var lineWidth, lineColor, borderDash, borderDashOffset;
        if (index === (typeof me.zeroLineIndex !== 'undefined' ? me.zeroLineIndex : 0) || index === me.ticks.length - 1) { //index === me.ticks.length - 1追加
          // Draw the first index specially
          lineWidth = gridLines.zeroLineWidth;
          lineColor = gridLines.zeroLineColor;
          borderDash = gridLines.zeroLineBorderDash;
          borderDashOffset = gridLines.zeroLineBorderDashOffset;
        } else {
          lineWidth = helpers.valueAtIndexOrDefault(gridLines.lineWidth, index);
          lineColor = helpers.valueAtIndexOrDefault(gridLines.color, index);
          borderDash = helpers.valueOrDefault(gridLines.borderDash, globalDefaults.borderDash);
          borderDashOffset = helpers.valueOrDefault(gridLines.borderDashOffset, globalDefaults.borderDashOffset);
        }

        // Common properties
        var tx1, ty1, tx2, ty2, x1, y1, x2, y2, labelX, labelY;
        var textAlign = 'middle';
        var textBaseline = 'middle';
        var tickPadding = optionTicks.padding;

        if (isHorizontal) {
          var labelYOffset = tl + tickPadding;

          if (options.position === 'bottom') {
            // bottom
            textBaseline = !isRotated ? 'top' : 'middle';
            textAlign = !isRotated ? 'center' : 'right';
            labelY = me.top + labelYOffset;
          } else {
            // top
            textBaseline = !isRotated ? 'bottom' : 'middle';
            textAlign = !isRotated ? 'center' : 'left';
            labelY = me.bottom - labelYOffset;
          }

          var xLineValue = me.getPixelForTick(index) + helpers.aliasPixel(lineWidth); // xvalues for grid lines
          labelX = me.getPixelForTick(index, gridLines.offsetGridLines) + optionTicks.labelOffset; // x values for optionTicks (need to consider offsetLabel option)

          tx1 = tx2 = x1 = x2 = xLineValue;
          ty1 = yTickStart;
          ty2 = yTickEnd;
          y1 = chartArea.top;
          y2 = chartArea.bottom;
        } else {
          var isLeft = options.position === 'left';
          var labelXOffset;

          if (optionTicks.mirror) {
            textAlign = isLeft ? 'left' : 'right';
            labelXOffset = tickPadding;
          } else {
            textAlign = isLeft ? 'right' : 'left';
            labelXOffset = tl + tickPadding;
          }

          labelX = isLeft ? me.right - labelXOffset : me.left + labelXOffset;

          var yLineValue = me.getPixelForTick(index); // xvalues for grid lines
          yLineValue += helpers.aliasPixel(lineWidth);
          labelY = me.getPixelForTick(index, gridLines.offsetGridLines) + optionTicks.labelOffset;

          tx1 = xTickStart;
          tx2 = xTickEnd;
          x1 = chartArea.left;
          x2 = chartArea.right;
          ty1 = ty2 = y1 = y2 = yLineValue;
        }

        itemsToDraw.push({
          tx1: tx1,
          ty1: ty1,
          tx2: tx2,
          ty2: ty2,
          x1: x1,
          y1: y1,
          x2: x2,
          y2: y2,
          labelX: labelX,
          labelY: labelY,
          glWidth: lineWidth,
          glColor: lineColor,
          glBorderDash: borderDash,
          glBorderDashOffset: borderDashOffset,
          rotation: -1 * labelRotationRadians,
          label: label,
          major: tick.major,
          textBaseline: textBaseline,
          textAlign: textAlign
        });
      });

      // Draw all of the tick labels, tick marks, and grid lines at the correct places
      helpers.each(itemsToDraw, function(itemToDraw) {
        if (gridLines.display) {
          context.save();
          context.lineWidth = itemToDraw.glWidth;
          context.strokeStyle = itemToDraw.glColor;
          if (context.setLineDash) {
            context.setLineDash(itemToDraw.glBorderDash);
            context.lineDashOffset = itemToDraw.glBorderDashOffset;
          }

          context.beginPath();

          if (gridLines.drawTicks) {
            context.moveTo(itemToDraw.tx1, itemToDraw.ty1);
            context.lineTo(itemToDraw.tx2, itemToDraw.ty2);
          }

          if (gridLines.drawOnChartArea) {
            context.moveTo(itemToDraw.x1, itemToDraw.y1);
            context.lineTo(itemToDraw.x2, itemToDraw.y2);
          }

          context.stroke();
          context.restore();
        }

        if (optionTicks.display) {
          // Make sure we draw text in the correct color and font
          context.save();
          context.translate(itemToDraw.labelX, itemToDraw.labelY);
          context.rotate(itemToDraw.rotation);
          context.font = itemToDraw.major ? majorTickFont.font : tickFont.font;
          context.fillStyle = itemToDraw.major ? majorTickFontColor : tickFontColor;
          context.textBaseline = itemToDraw.textBaseline;
          context.textAlign = itemToDraw.textAlign;

          var label = itemToDraw.label;
          if (helpers.isArray(label)) {
            for (var i = 0, y = 0; i < label.length; ++i) {
              // We just make sure the multiline element is a string here..
              context.fillText('' + label[i], 0, y);
              // apply same lineSpacing as calculated @ L#320
              y += (tickFont.size * 1.5);
            }
          } else {
            context.fillText(label, 0, 0);
          }
          context.restore();
        }
      });

      if (scaleLabel.display) {
        // Draw the scale label
        var scaleLabelX;
        var scaleLabelY;
        var rotation = 0;
        var _posFix = 34;

        if (isHorizontal) {
          scaleLabelX = me.left + ((me.right - me.left) / 2); // midpoint of the width
          scaleLabelY = options.position === 'bottom' ? me.bottom - halfLineHeight : me.top + halfLineHeight;
        } else {
          var isLeft = options.position === 'left';
          scaleLabelX = isLeft ? me.left + _posFix : me.right - _posFix + 16;
          scaleLabelY = me.top - 16;
          rotation = isLeft ? -0.5 * Math.PI : 0.5 * Math.PI;
        }

        context.save();
        context.translate(scaleLabelX, scaleLabelY);
        // context.rotate(rotation);
        context.textAlign = 'right';
        context.textBaseline = 'middle';
        context.fillStyle = scaleLabel.labelString !== null ? scaleLabelFontColor : "rgba(255,255,255,0.0)"; // render in correct colour
        context.font = scaleLabelFont.font;
        context.fillText("(" + scaleLabel.labelString + ")", 0, 0);
        context.restore();
      }

      if (gridLines.drawBorder) {
        // Draw the line at the edge of the axis
        context.lineWidth = helpers.valueAtIndexOrDefault(gridLines.lineWidth, 0);
        context.strokeStyle = helpers.valueAtIndexOrDefault(gridLines.color, 0);
        var x1 = me.left,
          x2 = me.right,
          y1 = me.top,
          y2 = me.bottom;

        var aliasPixel = helpers.aliasPixel(context.lineWidth);
        if (isHorizontal) {
          y1 = y2 = options.position === 'top' ? me.bottom : me.top;
          y1 += aliasPixel;
          y2 += aliasPixel;
        } else {
          x1 = x2 = options.position === 'left' ? me.right : me.left;
          x1 += aliasPixel;
          x2 += aliasPixel;
        }

        context.beginPath();
        context.moveTo(x1, y1);
        context.lineTo(x2, y2);
        context.stroke();
      }
    }
  });

  Chart.scaleService.registerScaleType('SRCPortalYAxis', SRCPortalYAxis, {position: 'bottom'});


})();
