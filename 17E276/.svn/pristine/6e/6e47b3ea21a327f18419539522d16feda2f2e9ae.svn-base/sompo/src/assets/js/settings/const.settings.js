var SRCPortal = SRCPortal ? SRCPortal : {};

SRCPortal.CONST = {
  "API_EATSMART": "http://caloriecheck.eatsmart.jp/",
  "API_REWARD": "/dummy/path/to/reward/api"
};
