/* globals Parsley */


/**
 * parsleyの設定。
 * エラーメッセージとtrigger
 */

//エラーメッセージ
Parsley.addMessages('ja', {
  defaultMessage: "無効な値です。",
  type: {
    email:        "有効なメールアドレスを入力してください。",
    url:          "有効なURLを入力してください。",
    number:       "数値を入力してください。",
    integer:      "整数を入力してください。",
    digits:       "数字を入力してください。",
    alphanum:     "英数字を入力してください。"
  },
  notblank:       "この値を入力してください",
  required:       "この値は必須です。",
  pattern:        "この値は無効です。",
  min:            "%s 以上の値にしてください。",
  max:            "%s 以下の値にしてください。",
  range:          "%s から %s の値にしてください。",
  minlength:      "%s 文字以上で入力してください。",
  maxlength:      "%s 文字以下で入力してください。",
  length:         "%s から %s 文字の間で入力してください。",
  mincheck:       "%s 個以上選択してください。",
  maxcheck:       "%s 個以下選択してください。",
  check:          "%s から %s 個選択してください。",
  equalto:        "値が一致しません。",
  dateiso:  "有効な日付を入力してください。 (YYYY-MM-DD).",
  minwords: "語句が短すぎます。 %s 語以上で入力してください。",
  maxwords: "語句が長すぎます。 %s 語以内で入力してください。",
  words:    "語句の長さが正しくありません。 %s 語から %s 語の間で入力してください。",
  gt:       "より大きい値を入力してください。",
  gte:      "より大きいか、同じ値を入力してください。",
  lt:       "より小さい値を入力してください。",
  lte:      "より小さいか、同じ値を入力してください。",
  notequalto: "異なる値を入力してください。"

});

//言語設定
Parsley.setLocale('ja');

//エラーが起こった際にinput等につけるclassをis-errorに設定
Parsley.options.errorClass = "is-error";

//エラーメッセージのラッパーをatom/form-error-msgに設定
Parsley.options.errorsWrapper = '<ul class="a-form-error-msg"></ul>';

//トリガー設定
Parsley.options.trigger = "keyup focusout change input";

///エラーが起こらなかった際にinput等につけるclassをis-successに設定
Parsley.options.successClass = "is-success";



//バリデータ：カタカナ (data-parsley-katakana="")
Parsley.addValidator('katakana', {
  requirementType: 'string',
  validateString: function(value, requirement) {
    return !!value.match(/^[\u30A0-\u30FF]+$/);
  },
  messages: {
    ja: '全角カタカナで入力してください'
  }
});


Parsley.addValidator('checkChildren', {
  messages: {
    en: "Input at least one.",
    ja: '少なくとも%sつ電話番号を入力してください。'
  },
  requirementType: 'string',
  validate: function(_value, requirement, instance) {
    var isValid = false;
    instance
      .$element
      .find(".address-phone-number")
      .each(function(){
        if($(this).val() !== ""){
          isValid = true;
        }
      });
    return isValid;
  }
});

//data-parsley-check-children
Parsley.options.inputs = Parsley.options.inputs + ',[data-parsley-check-children]';


