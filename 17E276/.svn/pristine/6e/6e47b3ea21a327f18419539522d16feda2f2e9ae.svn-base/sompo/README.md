SOMPO frontend
====

## required env
- node.js (latest ver[7.10.0])
- yarn (if not installed, run `$ npm install yarn -g`)
- gulp (if not installed, run `$ npm install gulp -g`)
- VSCode
- Editor plugins
    - EditorConfig for VS Code
    - ESLint
    - .ejs
    - language-stylus
    - Stylint

## how to develop
1. Run codes below.
```
$ cd /path/to/this/repo
$ yarn #install modules
$ yarn start #run dev server
```
2. Edit/create files under /src/pages


## directory structure

| path | description |
|:-- | :-- |
| /README.md     | This file. |
| /.editorconfig | Config file for indent style etc. |
| /.eslintrc     | Config file for linting JavaScript. |
| /.eslintignore | Config file for linting JavaScript. |
| /.gitignore    | Gitignore setting |
| /.sylintignore | Config file for linting Stylus. |
| /.stylintrc    | Config file for linting Stylus. |
| /gulpfile.babel.js | Config file for gulp. |
| /package.json  | Config file for npm/yarn. |
| /yarn.lock  | Config file for yarn to lock package ver. |
| /public        | Compiled files that are based on /src dir's files. |
| /src           | Codes before build. ejs, stylus, images, scripts. |


## Languages we use

- HTML template: [ejs](http://ejs.co/)
- CSS meta lang.: [stylus](http://stylus-lang.com/)
- Javascript: ES5


## 利用中のライブラリ

- [autosize(textareaの高さ調整)](http://www.jacklmoore.com/autosize/)
- [class.js(ES5のprototypeベースのクラスのラッパー)](https://github.com/nki2/classjs)
- [bowser(browser判定)](https://github.com/lancedikson/bowser)
- [chart.js(グラフ描画)](http://www.chartjs.org/)
- [jquery-throttle-debounce(イベントの間引き)](https://github.com/cowboy/jquery-throttle-debounce)
- [jquery dotdotdot(複数行テクストの省略)](http://dotdotdot.frebsite.nl/)
- [jquery.floatThead(tbodyのscroll)](http://mkoryak.github.io/floatThead/)
- [Sortable(drag&dropでのソート)](https://github.com/RubaXa/Sortable)
- [jquery-match-height(要素の高さを合わせる)](https://github.com/liabru/jquery-match-height)
- [jquery.mockjax(Ajaxのリクエストをインターセプトして返しすモックを作成する)](https://github.com/jakerella/jquery-mockjax)
- [jquery powertip(ツールチップ)](https://stevenbenner.github.io/jquery-powertip/)
- [jQuery ScrollTabs(スクロールタブ)](http://joshreed.github.io/jQuery-ScrollTabs/)
- [jQyery Mouse Wheel(マウスのホイールによるスクロールを可能にする.jQuery Scrolltabの利用箇所で連動)](https://github.com/jquery/jquery-mousewheel)
- [mustache.js(テンプレートエンジン.ST_03, LR_05の項目動的追加箇所に利用)](https://github.com/janl/mustache.js)
- [Parsley(フォームバリデーション)](http://parsleyjs.org/)
- [Swiper(コンテンツ・スライダー)](https://github.com/nolimits4web/Swiper)
- [Velocity.js(アニメーション)](http://velocityjs.org/)
## 利用するスニペット等
- https://jsfiddle.net/w262jh3e/1/
