import SkeletonScreen from './SkeletonScreen';
export default SkeletonScreen;
