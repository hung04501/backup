import * as React from 'react';

const NullComponent: React.StatelessComponent = () => {
  return null;
};

export default NullComponent;
