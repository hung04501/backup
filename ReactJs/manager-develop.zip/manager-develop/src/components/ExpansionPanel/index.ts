import ExpansionPanel, { Props as ExpansionPanelProps } from './ExpansionPanel';

export { ExpansionPanelProps };

export default ExpansionPanel;
