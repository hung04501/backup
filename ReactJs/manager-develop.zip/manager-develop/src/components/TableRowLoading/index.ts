export { default, Props as TableRowProps } from './TableRowLoading';
