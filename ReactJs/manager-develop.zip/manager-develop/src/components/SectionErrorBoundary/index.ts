import SectionErrorBoundary from './SectionErrorBoundary';
export default SectionErrorBoundary;
