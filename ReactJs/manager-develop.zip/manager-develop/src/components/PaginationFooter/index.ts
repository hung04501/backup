
export { default, PaginationProps } from './PaginationFooter';
