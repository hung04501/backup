import Grid, { Props } from './Grid';

export { Props as GridProps };

export default Grid;
