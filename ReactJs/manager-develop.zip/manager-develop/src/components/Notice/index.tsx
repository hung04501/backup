import Notice from './Notice';
export default Notice;
