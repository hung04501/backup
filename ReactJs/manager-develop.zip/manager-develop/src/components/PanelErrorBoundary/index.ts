import PanelErrorBoundary from './PanelErrorBoundary';
export default PanelErrorBoundary;
