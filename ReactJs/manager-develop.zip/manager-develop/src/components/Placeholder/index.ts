import Placeholder, { Props as PlaceholderProps } from './Placeholder';

export {
  PlaceholderProps,
};

export default Placeholder;
