import SelectRegionPanel, { ExtendedRegion } from './SelectRegionPanel';

export { ExtendedRegion };

export default SelectRegionPanel;
