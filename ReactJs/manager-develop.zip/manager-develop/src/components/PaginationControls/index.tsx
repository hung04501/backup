import PaginationControls from './PaginationControls';
export default PaginationControls;
