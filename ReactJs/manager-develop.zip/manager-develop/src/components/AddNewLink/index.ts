import AddNewLink, { Props } from './AddNewLink';

export { Props };

export default AddNewLink;
