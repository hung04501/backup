import EditableText from './EditableText';
export default EditableText;
