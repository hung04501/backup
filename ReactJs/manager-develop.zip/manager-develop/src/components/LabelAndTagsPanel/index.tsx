import LabelAndTagsPanel from './LabelAndTagsPanel';
export default LabelAndTagsPanel;
