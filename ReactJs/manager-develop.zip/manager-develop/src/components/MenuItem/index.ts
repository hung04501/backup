import MenuItem from './MenuItem';

export default MenuItem;
