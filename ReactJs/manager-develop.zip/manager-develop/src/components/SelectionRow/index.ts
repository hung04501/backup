import SelectionRow, { Props as SelectionRowProps } from './SelectionRow';

export { SelectionRowProps };

export default SelectionRow;
