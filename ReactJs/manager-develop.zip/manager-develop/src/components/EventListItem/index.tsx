import EventListItem from './EventListItem';
export default EventListItem;
