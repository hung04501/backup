import TabbedPanel from './TabbedPanel';
export default TabbedPanel;
