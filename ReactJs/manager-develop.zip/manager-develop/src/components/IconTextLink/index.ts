import IconTextLink, { Props as IconTextLinkProps } from './IconTextLink';

export {
  IconTextLinkProps,
};

export default IconTextLink;
