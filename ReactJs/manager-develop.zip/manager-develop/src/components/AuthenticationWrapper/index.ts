import AuthenticationWrapper from './AuthenticationWrapper';
export default AuthenticationWrapper;
