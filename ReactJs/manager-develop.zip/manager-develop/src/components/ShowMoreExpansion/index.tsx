import ShowMoreExpansion from './ShowMoreExpansion';
export default ShowMoreExpansion;
