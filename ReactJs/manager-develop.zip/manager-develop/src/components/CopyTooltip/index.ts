import CopyTooltip from './CopyTooltip';
export default CopyTooltip;
