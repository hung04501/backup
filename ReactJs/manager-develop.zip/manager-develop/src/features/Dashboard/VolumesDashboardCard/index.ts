export { default } from './VolumesDashboardCard';
