import StackScripts from './StackScripts';
export default StackScripts;
