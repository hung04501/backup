import StackScriptUpdate from './StackScriptUpdate';
export default StackScriptUpdate;