import ScriptForm from './StackScriptForm';
export default ScriptForm;