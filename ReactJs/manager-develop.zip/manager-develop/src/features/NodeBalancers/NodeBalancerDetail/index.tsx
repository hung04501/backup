import NodeBalancerDetail from './NodeBalancerDetail';
export default NodeBalancerDetail;
