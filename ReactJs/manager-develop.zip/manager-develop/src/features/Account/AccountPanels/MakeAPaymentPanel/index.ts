export { default } from './MakeAPaymentPanel';
