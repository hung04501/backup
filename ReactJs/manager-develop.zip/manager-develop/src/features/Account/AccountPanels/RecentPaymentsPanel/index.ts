export { default } from './RecentPaymentsPanel';
