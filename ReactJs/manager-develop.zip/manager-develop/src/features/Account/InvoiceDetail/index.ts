export { default } from './InvoiceDetail';
