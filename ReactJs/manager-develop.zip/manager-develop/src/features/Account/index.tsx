export {default} from './AccountDetail';
