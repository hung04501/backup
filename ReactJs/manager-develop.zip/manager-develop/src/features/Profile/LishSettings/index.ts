import LishSettings from './LishSettings';
export default LishSettings;
