import Referrals from './Referrals';
export default Referrals;
