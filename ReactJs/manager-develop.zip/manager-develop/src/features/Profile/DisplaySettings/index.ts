import DisplaySettings from './DisplaySettings';
export default DisplaySettings;
