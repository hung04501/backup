import TwoFactor from './TwoFactor';
export default TwoFactor;
