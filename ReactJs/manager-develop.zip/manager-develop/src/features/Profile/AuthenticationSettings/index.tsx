import AuthenticationSettings from './AuthenticationSettings';
export default AuthenticationSettings;
