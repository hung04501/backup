export { default } from './SupportTicketDetail';
