declare module 'novnc-node' {
  export const RFB: any;
}
