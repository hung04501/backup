#!/bin/bash

yarn build

yarn serve
