window.onload = function() {
  document.getElementById('output').innerHTML += '<br>INSECURE SCRIPT LOADED AND RUN!!!';
}