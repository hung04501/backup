```
npm install
npm run serve
```
