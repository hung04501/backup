## redux observable cancellable counter ##

This is the porting of the redux saga cancellable counter example.
It's slightly different from the original one in the management on how the initial epic is started, and terminated.

Package with:

    npm run webpack
    
run with:

    npm start
    
    