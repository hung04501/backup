## Redux Observable shopping cart ##
 
 This is the porting of the redux-saga-shopping-cart.
 The saga has been transformed into an equivalent epic, all the other code is pretty much the same. 