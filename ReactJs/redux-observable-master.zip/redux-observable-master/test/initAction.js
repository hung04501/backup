import { __DO_NOT_USE__ActionTypes as actionTypes } from 'redux';

export const initAction = { type: actionTypes.INIT };
