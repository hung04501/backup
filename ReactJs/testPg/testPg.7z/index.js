const express = require('express');
const app = express();
const pg = require('pg');
const port = 3000;

const config = {
    user: 'postgres',
    database: 'clkdb_20180416',
    password: 'postgres',
    port: 5432
};
const results = [];

const pool = new pg.Pool(config);


app.get('/', (req, res, next) => {
   pool.connect(function (err, client, done) {
       if (err) {
           console.log("Can not connect to the DB" + err);
       }
       client.query('SELECT cust_id,cust_name from m_customer', function (err, result) {
            done();
            if (err) {
                console.log(err);
                res.status(400).send(err);
            } else {
				//cust branch
			   client.query('SELECT distinct cust_id from m_customer_branch', function (err, result1) {
					done();
					if (err) {
						console.log(err);
						res.status(400).send(err);
					}
					res.json(result1.rows);
			   });
			}
			pool.end();
            res.json(result.rows);
       });
	   
   })
   
});

app.listen(port, () => console.log(`Example app listening on port ${port}!`))






