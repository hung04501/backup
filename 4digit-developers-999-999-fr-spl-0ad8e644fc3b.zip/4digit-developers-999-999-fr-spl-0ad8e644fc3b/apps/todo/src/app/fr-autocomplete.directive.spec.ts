import { FrAutocompleteDirective } from './fr-autocomplete.directive';

describe('FrAutocompleteDirective', () => {
  it('should create an instance', () => {
    const directive = new FrAutocompleteDirective(null, null, null, null);
    expect(directive).toBeTruthy();
  });
});
