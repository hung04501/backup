import { App } from './app.interfaces';

export const appInitialState: App = {
  // fill it initial state here
  counter: 10
};
