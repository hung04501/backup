import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-new',
  templateUrl: './booking-new.component.html',
  styleUrls: ['./booking-new.component.scss']
})
export class BookingNewComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
