import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a-textfield',
  templateUrl: './textfield.component.html',
  styleUrls: ['./textfield.component.scss']
})
export class TextfieldComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
