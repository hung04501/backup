import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a-btn',
  templateUrl: './btn.component.html',
  styleUrls: ['./btn.component.scss']
})
export class BtnComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
