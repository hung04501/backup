// import { routingReducer } from './routing.reducer';
// import { routingInitialState } from './routing.init';
// import { Routing } from './routing.interfaces';
// import { DataLoaded } from './routing.actions';

describe('routingReducer', () => {
  // it('should work', () => {
  //   const state: Routing = {};
  //   const action: DataLoaded = { type: 'DATA_LOADED', payload: {} };
  //   const actual = routingReducer(state, action);
  //   expect(actual).toEqual({});
  // });
});
